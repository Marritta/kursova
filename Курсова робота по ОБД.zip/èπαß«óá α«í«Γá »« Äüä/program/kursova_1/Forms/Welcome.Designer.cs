﻿namespace kursova_1.Forms
{
    partial class Welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWelcome1 = new System.Windows.Forms.Label();
            this.buttonAdmin = new System.Windows.Forms.Button();
            this.buttonDisp = new System.Windows.Forms.Button();
            this.buttonVodiy = new System.Windows.Forms.Button();
            this.buttonKonduct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWelcome1
            // 
            this.labelWelcome1.Location = new System.Drawing.Point(335, 56);
            this.labelWelcome1.Name = "labelWelcome1";
            this.labelWelcome1.Size = new System.Drawing.Size(130, 39);
            this.labelWelcome1.TabIndex = 0;
            this.labelWelcome1.Text = "Вітаємо в системі.\r\n\r\nУвійти як:";
            this.labelWelcome1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonAdmin
            // 
            this.buttonAdmin.Location = new System.Drawing.Point(335, 120);
            this.buttonAdmin.Name = "buttonAdmin";
            this.buttonAdmin.Size = new System.Drawing.Size(130, 30);
            this.buttonAdmin.TabIndex = 1;
            this.buttonAdmin.Text = "Адміністратор";
            this.buttonAdmin.UseVisualStyleBackColor = true;
            this.buttonAdmin.Click += new System.EventHandler(this.buttonAdmin_Click);
            // 
            // buttonDisp
            // 
            this.buttonDisp.Location = new System.Drawing.Point(335, 186);
            this.buttonDisp.Name = "buttonDisp";
            this.buttonDisp.Size = new System.Drawing.Size(130, 30);
            this.buttonDisp.TabIndex = 2;
            this.buttonDisp.Text = "Діспетчер";
            this.buttonDisp.UseVisualStyleBackColor = true;
            this.buttonDisp.Click += new System.EventHandler(this.buttonDisp_Click);
            // 
            // buttonVodiy
            // 
            this.buttonVodiy.Location = new System.Drawing.Point(335, 253);
            this.buttonVodiy.Name = "buttonVodiy";
            this.buttonVodiy.Size = new System.Drawing.Size(130, 30);
            this.buttonVodiy.TabIndex = 3;
            this.buttonVodiy.Text = "Водій";
            this.buttonVodiy.UseVisualStyleBackColor = true;
            this.buttonVodiy.Click += new System.EventHandler(this.buttonVodiy_Click);
            // 
            // buttonKonduct
            // 
            this.buttonKonduct.Location = new System.Drawing.Point(335, 316);
            this.buttonKonduct.Name = "buttonKonduct";
            this.buttonKonduct.Size = new System.Drawing.Size(130, 30);
            this.buttonKonduct.TabIndex = 4;
            this.buttonKonduct.Text = "Кондуктор";
            this.buttonKonduct.UseVisualStyleBackColor = true;
            this.buttonKonduct.Click += new System.EventHandler(this.buttonKonduct_Click);
            // 
            // Welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.buttonKonduct);
            this.Controls.Add(this.buttonVodiy);
            this.Controls.Add(this.buttonDisp);
            this.Controls.Add(this.buttonAdmin);
            this.Controls.Add(this.labelWelcome1);
            this.Name = "Welcome";
            this.Text = " ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelWelcome1;
        private System.Windows.Forms.Button buttonAdmin;
        private System.Windows.Forms.Button buttonDisp;
        private System.Windows.Forms.Button buttonVodiy;
        private System.Windows.Forms.Button buttonKonduct;
    }
}