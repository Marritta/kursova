﻿using kursova_1.Forms.AdminForms;
using kursova_1.Forms.DispForms;
using kursova_1.Forms.KondForms;
using kursova_1.Forms.VodForms;
using System;
using System.Windows.Forms;

namespace kursova_1.Forms
{
    public partial class FormPassword : Form
    {
        public FormPassword()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void buttonPassword_Click(object sender, EventArgs e)
        {
            // Получение введенного пароля
            string enteredPassword = textBoxPassword.Text;

            // Проверка пароля и переход на соответствующую форму
            if (CheckPassword(enteredPassword, "admin"))
            {
                // Переход на FormAdmin
                FormAdmin formAdmin = new FormAdmin();
                formAdmin.Show();
                this.Hide(); // Скрываем текущую форму
            }
            else if (CheckPassword(enteredPassword, "disp"))
            {
                // Переход на FormDisp
                FormDisp formDisp = new FormDisp();
                formDisp.Show();
                this.Hide();
            }
            else if (CheckPassword(enteredPassword, "kond"))
            {
                // Переход на FormKond
                FormKond formKond = new FormKond();
                formKond.Show();
                this.Hide();
            }
            else if (CheckPassword(enteredPassword, "vod"))
            {
                // Переход на FormVod
                FormVod formVod = new FormVod();
                formVod.Show();
                this.Hide();
            }
            else
            {
                // Вывод сообщения об ошибке, если пароль неверный
                MessageBox.Show("Було введено невірний пароль або у вас немає прав до цього розділу.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        // Метод для проверки пароля
        private bool CheckPassword(string enteredPassword, string correctPassword)
        {
            // Здесь может быть более сложная логика проверки пароля
            return enteredPassword == correctPassword;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            Welcome welcomeForm = new Welcome();

            // Відображення форми Welcome
            welcomeForm.Show();

            // Закриття поточної форми
            this.Close();
        }
    }
}
