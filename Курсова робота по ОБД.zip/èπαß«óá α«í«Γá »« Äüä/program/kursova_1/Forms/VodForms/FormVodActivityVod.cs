﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace kursova_1.Forms.VodForms
{
    public partial class FormVodActivityVod : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormVodActivityVod()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxActivityVod.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActivityVod.Items.AddRange(new object[] { "True", "False" });
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
           
            dataGridViewVod.Columns.Add("Ном_Робіт_Водій", "Ном_Робіт_Водій");
            dataGridViewVod.Columns.Add("АктивністьВодій", "АктивністьВодій");

        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(
                record.GetInt32(0),
                record.GetValue(1)
            );
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Водій";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод изменения рядка
        private void Change()
        {
            int nomVod;
            string activityVod = comboBoxActivityVod.SelectedItem?.ToString();




                if (dataGridViewVod.SelectedRows.Count > 0)
                {
                    // Отримуємо значення ключів для зміни рядка
                int nomVodToUpdate = Convert.ToInt32(dataGridViewVod.SelectedRows[0].Cells["Ном_Робіт_Водій"].Value);

                string activityVodToUpdateToUpdate = Convert.ToString(dataGridViewVod.SelectedRows[0].Cells["АктивністьВодій"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                    // Змінюємо дані рядка
                    string newactivityVod = Convert.ToString(comboBoxActivityVod.SelectedItem?.ToString()); 
                    // Перевірка, чи дані змінилися
                    if (newactivityVod == activityVodToUpdateToUpdate)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }




                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Водій SET АктивністьВодій = @NewactivityVod " +
                                             "WHERE Ном_Робіт_Водій = @NomVodToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomVodToUpdate", nomVodToUpdate);
                            command.Parameters.AddWithValue("@NewactivityVod", newactivityVod);


                            dataBase.openConnection();
                            command.ExecuteNonQuery();
                            dataBase.closeConnection();

                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewVod);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            

        }
        //метод поиска 
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Водій where convert(nvarchar(max), Ном_Робіт_Водій) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormVod formVod = new FormVod();

            // Виклик методу Show() для відображення нової форми
            formVod.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNomVod.Text = "";
        }

        private void FormVodActivityVod_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewVod);
        }

        private void dataGridViewVod_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewVod.Rows[selectedRow];

               textBoxNomVod.Text = row.Cells[0].Value.ToString();
                comboBoxActivityVod.Text = row.Cells[1].Value.ToString();

            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewVod);
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }
    }
}
