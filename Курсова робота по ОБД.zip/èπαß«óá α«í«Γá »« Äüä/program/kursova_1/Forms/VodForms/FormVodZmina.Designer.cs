﻿namespace kursova_1.Forms.VodForms
{
    partial class FormVodZmina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.dataGridViewVodZmin = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonUpdateZapis = new System.Windows.Forms.Button();
            this.buttonRefreshDani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxKilkReys = new System.Windows.Forms.TextBox();
            this.textBoxTimeBreak = new System.Windows.Forms.TextBox();
            this.textBoxTimeEnd = new System.Windows.Forms.TextBox();
            this.textBoxTimeStart = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVodZmin)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 59);
            this.panel1.TabIndex = 2;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(529, 18);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(71, 20);
            this.buttonRefresh.TabIndex = 4;
            this.buttonRefresh.Text = "Оновити";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(628, 18);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(129, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Зміна";
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(749, 19);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 3;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // dataGridViewVodZmin
            // 
            this.dataGridViewVodZmin.AllowUserToAddRows = false;
            this.dataGridViewVodZmin.AllowUserToDeleteRows = false;
            this.dataGridViewVodZmin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVodZmin.Location = new System.Drawing.Point(12, 120);
            this.dataGridViewVodZmin.Name = "dataGridViewVodZmin";
            this.dataGridViewVodZmin.ReadOnly = true;
            this.dataGridViewVodZmin.Size = new System.Drawing.Size(776, 225);
            this.dataGridViewVodZmin.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.textBoxKilkReys);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textBoxTimeBreak);
            this.panel2.Controls.Add(this.textBoxTimeEnd);
            this.panel2.Controls.Add(this.textBoxTimeStart);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 351);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(418, 189);
            this.panel2.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Кількість виконаних рейсів";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Кількість годин відпочинку";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(137, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Час закінчення";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(155, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Час початку";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дані:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.buttonUpdateZapis);
            this.panel3.Controls.Add(this.buttonRefreshDani);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(541, 351);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 189);
            this.panel3.TabIndex = 14;
            // 
            // buttonUpdateZapis
            // 
            this.buttonUpdateZapis.Location = new System.Drawing.Point(24, 94);
            this.buttonUpdateZapis.Name = "buttonUpdateZapis";
            this.buttonUpdateZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonUpdateZapis.TabIndex = 3;
            this.buttonUpdateZapis.Text = "Змінити";
            this.buttonUpdateZapis.UseVisualStyleBackColor = true;
            this.buttonUpdateZapis.Click += new System.EventHandler(this.buttonUpdateZapis_Click);
            // 
            // buttonRefreshDani
            // 
            this.buttonRefreshDani.Location = new System.Drawing.Point(24, 57);
            this.buttonRefreshDani.Name = "buttonRefreshDani";
            this.buttonRefreshDani.Size = new System.Drawing.Size(131, 23);
            this.buttonRefreshDani.TabIndex = 1;
            this.buttonRefreshDani.Text = "Очистити дані";
            this.buttonRefreshDani.UseVisualStyleBackColor = true;
            this.buttonRefreshDani.Click += new System.EventHandler(this.buttonRefreshDani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Управління записами";
            // 
            // textBoxKilkReys
            // 
            this.textBoxKilkReys.Location = new System.Drawing.Point(238, 122);
            this.textBoxKilkReys.Name = "textBoxKilkReys";
            this.textBoxKilkReys.Size = new System.Drawing.Size(156, 20);
            this.textBoxKilkReys.TabIndex = 9;
            // 
            // textBoxTimeBreak
            // 
            this.textBoxTimeBreak.Location = new System.Drawing.Point(238, 91);
            this.textBoxTimeBreak.Name = "textBoxTimeBreak";
            this.textBoxTimeBreak.Size = new System.Drawing.Size(156, 20);
            this.textBoxTimeBreak.TabIndex = 7;
            // 
            // textBoxTimeEnd
            // 
            this.textBoxTimeEnd.Location = new System.Drawing.Point(238, 64);
            this.textBoxTimeEnd.Name = "textBoxTimeEnd";
            this.textBoxTimeEnd.Size = new System.Drawing.Size(156, 20);
            this.textBoxTimeEnd.TabIndex = 6;
            // 
            // textBoxTimeStart
            // 
            this.textBoxTimeStart.Location = new System.Drawing.Point(238, 35);
            this.textBoxTimeStart.Name = "textBoxTimeStart";
            this.textBoxTimeStart.Size = new System.Drawing.Size(156, 20);
            this.textBoxTimeStart.TabIndex = 5;
            // 
            // FormVodZmina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridViewVodZmin);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.panel1);
            this.Name = "FormVodZmina";
            this.Text = "FormVodZmina";
            this.Load += new System.EventHandler(this.FormVodZmina_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVodZmin)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.DataGridView dataGridViewVodZmin;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonUpdateZapis;
        private System.Windows.Forms.Button buttonRefreshDani;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxKilkReys;
        private System.Windows.Forms.TextBox textBoxTimeBreak;
        private System.Windows.Forms.TextBox textBoxTimeEnd;
        private System.Windows.Forms.TextBox textBoxTimeStart;
    }
}