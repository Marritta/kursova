﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace kursova_1.Forms.VodForms
{
    public partial class FormVodZmina : Form
    {
        DataBase dataBase = new DataBase();
        int selected;
        public FormVodZmina()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewVodZmin.Columns.Add("ДатаПлан", "Дата Плану");
            dataGridViewVodZmin.Columns.Add("Номер_марш", "Номер маршруту");
            dataGridViewVodZmin.Columns.Add("Держ_номер_А", "Державний номер автобусу");
            dataGridViewVodZmin.Columns.Add("Номер_Зміни", "Номер зміни");
            dataGridViewVodZmin.Columns.Add("Ном_Робіт_Водій", "Номер Водія");
            dataGridViewVodZmin.Columns.Add("Час_початок", "Час_початок");
            dataGridViewVodZmin.Columns.Add("Час_кінець", "Час_кінець");
            dataGridViewVodZmin.Columns.Add("Години_відпочинок", "Години_відпочинок");
            dataGridViewVodZmin.Columns.Add("Кільк_викон_рейсів", "Кільк_викон_рейсів");
        }
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(
                record.GetDateTime(0),           // ДатаПлан
                record.GetInt32(1),              // Номер_марш
                record.GetString(2),             // Держ_номер_А
                record.GetInt32(3),              // Номер_Зміни
                record.GetInt32(4),              // Ном_Робіт_Водій
                record.IsDBNull(5) ? "" : (record.GetValue(5) is TimeSpan ? ((TimeSpan)record.GetValue(5)).ToString(@"hh\:mm\:ss") : ""), // Час_початок
                record.IsDBNull(6) ? "" : (record.GetValue(6) is TimeSpan ? ((TimeSpan)record.GetValue(6)).ToString(@"hh\:mm\:ss") : ""), // Час_кінець
                record.IsDBNull(7) ? "" : (record.GetValue(7) is TimeSpan ? ((TimeSpan)record.GetValue(7)).ToString(@"hh\:mm\:ss") : ""), // Години_відпочинок
                record.IsDBNull(8) ? (int?)null : record.GetInt32(8) // Кільк_викон_рейсів
            );
        }

        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Зміна where convert(nvarchar(max), ДатаПлан) + convert(nvarchar(max), Номер_марш) + convert(nvarchar(max), Держ_номер_А)" +
                $"+ convert(nvarchar(max), Номер_Зміни)+ convert(nvarchar(max), Ном_Робіт_Водій) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select ДатаПлан,Номер_марш,Держ_номер_А,Номер_Зміни,Ном_Робіт_Водій,Час_початок,Час_кінець,Години_відпочинок,Кільк_викон_рейсів from Зміна";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод изменения рядка
        private void Change()
        {
            TimeSpan timestart;
            TimeSpan timeend;
            TimeSpan timebreak;
            int kilkReys;
            if (int.TryParse(textBoxKilkReys.Text, out kilkReys) && TimeSpan.TryParse(textBoxTimeStart.Text, out timestart)
                 && TimeSpan.TryParse(textBoxTimeEnd.Text, out timeend) && TimeSpan.TryParse(textBoxTimeBreak.Text, out timebreak))
            {
                if (dataGridViewVodZmin.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                    // Отримуємо значення ключів для зміни рядка
                    string dateToUpdateStr = Convert.ToString(dataGridViewVodZmin.SelectedRows[0].Cells["ДатаПлан"].Value);
                    string nomMarshToUpdateStr = Convert.ToString(dataGridViewVodZmin.SelectedRows[0].Cells["Номер_марш"].Value);
                    string nomAToUpdate = Convert.ToString(dataGridViewVodZmin.SelectedRows[0].Cells["Держ_номер_А"].Value);
                    string nomZminToUpdateStr = Convert.ToString(dataGridViewVodZmin.SelectedRows[0].Cells["Номер_Зміни"].Value);

                    DateTime dateplToUpdate = DateTime.Parse(dateToUpdateStr);
                    int nomMarshToUpdate = int.Parse(nomMarshToUpdateStr);
                    int nomZminToUpdate = int.Parse(nomZminToUpdateStr);


                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        string newtimestartString = textBoxTimeStart.Text;
                        string newtimeendString = textBoxTimeEnd.Text;
                        string newtimebreakString = textBoxTimeBreak.Text;
                        TimeSpan newtimestart = TimeSpan.Parse(newtimestartString); 
                        TimeSpan newtimeend = TimeSpan.Parse(newtimeendString); 
                        TimeSpan newtimebreak = TimeSpan.Parse(newtimebreakString); 
                        int newkilkReys = Convert.ToInt32(textBoxKilkReys.Text);



                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Зміна SET " +
                                                 "Час_початок = @Newtimestart, " +
                                                 "Час_кінець = @Newtimeend, " +
                                                 "Години_відпочинок = @Newtimebreak, " +
                                                 "Кільк_викон_рейсів = @NewkilkReys " +
                                                 "WHERE ДатаПлан = @DatePlanToUpdate and Номер_марш = @NomMarshToUpdate and Держ_номер_А = @NomAvtToUpdate and Номер_Зміни = @NomZminToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@DatePlanToUpdate", dateplToUpdate);
                            command.Parameters.AddWithValue("@NomMarshToUpdate", nomMarshToUpdate);
                            command.Parameters.AddWithValue("@NomAvtToUpdate", nomAToUpdate);
                            command.Parameters.AddWithValue("@NomZminToUpdate", nomZminToUpdate);
                            command.Parameters.AddWithValue("@Newtimestart", newtimestart);
                            command.Parameters.AddWithValue("@Newtimeend", newtimeend);
                            command.Parameters.AddWithValue("@Newtimebreak", newtimebreak);
                            command.Parameters.AddWithValue("@NewkilkReys", newkilkReys);
                            command.ExecuteNonQuery();



                            command.ExecuteNonQuery();


                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewVodZmin);
                        }
                    }
                    dataBase.closeConnection();
            }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormVod formVod = new FormVod();

            // Виклик методу Show() для відображення нової форми
            formVod.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void FormVodZmina_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewVodZmin);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxKilkReys.Text = "";
            textBoxTimeBreak.Text = "";
            textBoxTimeEnd.Text = "";
            textBoxTimeStart.Text = "";
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewVodZmin);
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewVodZmin);
        }
    }
}
