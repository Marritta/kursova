﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursova_1.Forms.VodForms
{
    public partial class FormVod : Form
    {
        public FormVod()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            Welcome welcomeForm = new Welcome();

            // Відображення форми Welcome
            welcomeForm.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonVod_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
           FormVodActivityVod formVodActivityVod = new FormVodActivityVod();

            // Відображення форми Welcome
            formVodActivityVod.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonVodZmina_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormVodZmina formVodZmina = new FormVodZmina();

            // Відображення форми Welcome
            formVodZmina.Show();

            // Закриття поточної форми
            this.Close();
        }
    }
}
