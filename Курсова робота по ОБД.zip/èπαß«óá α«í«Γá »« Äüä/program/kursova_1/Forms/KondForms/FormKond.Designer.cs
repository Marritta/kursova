﻿namespace kursova_1.Forms.KondForms
{
    partial class FormKond
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.labelHeader = new System.Windows.Forms.Label();
            this.buttonKond = new System.Windows.Forms.Button();
            this.buttonKondZmina = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.linkLabelBack);
            this.panel1.Controls.Add(this.labelHeader);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(8, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(780, 50);
            this.panel1.TabIndex = 2;
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(723, 17);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 1;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // labelHeader
            // 
            this.labelHeader.AutoSize = true;
            this.labelHeader.Location = new System.Drawing.Point(18, 17);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new System.Drawing.Size(179, 13);
            this.labelHeader.TabIndex = 0;
            this.labelHeader.Text = "Вітаємо, Кондукторе. Оберіть дію.";
            // 
            // buttonKond
            // 
            this.buttonKond.Location = new System.Drawing.Point(12, 133);
            this.buttonKond.Name = "buttonKond";
            this.buttonKond.Size = new System.Drawing.Size(172, 54);
            this.buttonKond.TabIndex = 3;
            this.buttonKond.Text = "Відзначення активності";
            this.buttonKond.UseVisualStyleBackColor = true;
            this.buttonKond.Click += new System.EventHandler(this.buttonKond_Click);
            // 
            // buttonKondZmina
            // 
            this.buttonKondZmina.Location = new System.Drawing.Point(12, 227);
            this.buttonKondZmina.Name = "buttonKondZmina";
            this.buttonKondZmina.Size = new System.Drawing.Size(172, 54);
            this.buttonKondZmina.TabIndex = 4;
            this.buttonKondZmina.Text = "Заповнення Зміни";
            this.buttonKondZmina.UseVisualStyleBackColor = true;
            this.buttonKondZmina.Click += new System.EventHandler(this.buttonKondZmina_Click);
            // 
            // FormKond
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonKondZmina);
            this.Controls.Add(this.buttonKond);
            this.Controls.Add(this.panel1);
            this.Name = "FormKond";
            this.Text = "FormKond";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.Label labelHeader;
        private System.Windows.Forms.Button buttonKond;
        private System.Windows.Forms.Button buttonKondZmina;
    }
}