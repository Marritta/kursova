﻿namespace kursova_1.Forms.KondForms
{
    partial class FormKondActivityKond
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.dataGridViewKond = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBoxActivityKond = new System.Windows.Forms.ComboBox();
            this.textBoxNomKond = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonUpdateZapis = new System.Windows.Forms.Button();
            this.buttonRefreshDani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKond)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 59);
            this.panel1.TabIndex = 2;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(531, 18);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(71, 20);
            this.buttonRefresh.TabIndex = 3;
            this.buttonRefresh.Text = "Оновити";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(628, 18);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(129, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Кондуктор";
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(749, 26);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 5;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // dataGridViewKond
            // 
            this.dataGridViewKond.AllowUserToAddRows = false;
            this.dataGridViewKond.AllowUserToDeleteRows = false;
            this.dataGridViewKond.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKond.Location = new System.Drawing.Point(12, 107);
            this.dataGridViewKond.Name = "dataGridViewKond";
            this.dataGridViewKond.Size = new System.Drawing.Size(776, 237);
            this.dataGridViewKond.TabIndex = 6;
            this.dataGridViewKond.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewKond_CellClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.comboBoxActivityKond);
            this.panel2.Controls.Add(this.textBoxNomKond);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 367);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(438, 169);
            this.panel2.TabIndex = 7;
            // 
            // comboBoxActivityKond
            // 
            this.comboBoxActivityKond.FormattingEnabled = true;
            this.comboBoxActivityKond.Location = new System.Drawing.Point(228, 74);
            this.comboBoxActivityKond.Name = "comboBoxActivityKond";
            this.comboBoxActivityKond.Size = new System.Drawing.Size(155, 21);
            this.comboBoxActivityKond.TabIndex = 7;
            // 
            // textBoxNomKond
            // 
            this.textBoxNomKond.Location = new System.Drawing.Point(228, 33);
            this.textBoxNomKond.Name = "textBoxNomKond";
            this.textBoxNomKond.Size = new System.Drawing.Size(156, 20);
            this.textBoxNomKond.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(99, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Активність кондуктора";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(120, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Номер кондуктора";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дані:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.buttonUpdateZapis);
            this.panel3.Controls.Add(this.buttonRefreshDani);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(539, 367);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 169);
            this.panel3.TabIndex = 8;
            // 
            // buttonUpdateZapis
            // 
            this.buttonUpdateZapis.Location = new System.Drawing.Point(8, 77);
            this.buttonUpdateZapis.Name = "buttonUpdateZapis";
            this.buttonUpdateZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonUpdateZapis.TabIndex = 3;
            this.buttonUpdateZapis.Text = "Змінити";
            this.buttonUpdateZapis.UseVisualStyleBackColor = true;
            this.buttonUpdateZapis.Click += new System.EventHandler(this.buttonUpdateZapis_Click);
            // 
            // buttonRefreshDani
            // 
            this.buttonRefreshDani.Location = new System.Drawing.Point(8, 30);
            this.buttonRefreshDani.Name = "buttonRefreshDani";
            this.buttonRefreshDani.Size = new System.Drawing.Size(131, 23);
            this.buttonRefreshDani.TabIndex = 1;
            this.buttonRefreshDani.Text = "Очистити дані";
            this.buttonRefreshDani.UseVisualStyleBackColor = true;
            this.buttonRefreshDani.Click += new System.EventHandler(this.buttonRefreshDani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Управління записами";
            // 
            // FormKondActivityKond
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridViewKond);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.panel1);
            this.Name = "FormKondActivityKond";
            this.Text = "FormActivityKond";
            this.Load += new System.EventHandler(this.FormKondActivityKond_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKond)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.DataGridView dataGridViewKond;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxNomKond;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonUpdateZapis;
        private System.Windows.Forms.Button buttonRefreshDani;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxActivityKond;
    }
}