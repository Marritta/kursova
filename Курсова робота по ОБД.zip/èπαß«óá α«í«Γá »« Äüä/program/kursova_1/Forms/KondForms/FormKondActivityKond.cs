﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace kursova_1.Forms.KondForms
{
    public partial class FormKondActivityKond : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormKondActivityKond()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxActivityKond.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActivityKond.Items.AddRange(new object[] { "True", "False" });
        }
        //метод створення атрибутов
        private void CreateColumns()
        {

            dataGridViewKond.Columns.Add("Ном_Робіт_Кондуктор", "Ном_Робіт_Кондуктор");
            dataGridViewKond.Columns.Add("АктивністьКондуктор", "АктивністьКондуктор");

        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(
                record.GetInt32(0),
                record.GetValue(1)
            );
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Кондуктор";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод изменения рядка
        private void Change()
        {
            int nomKond;
            string activityKond = comboBoxActivityKond.SelectedItem?.ToString();




            if (dataGridViewKond.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для зміни рядка
                int nomKondToUpdate = Convert.ToInt32(dataGridViewKond.SelectedRows[0].Cells["Ном_Робіт_Кондуктор"].Value);

                string activityKondToUpdateToUpdate = Convert.ToString(dataGridViewKond.SelectedRows[0].Cells["АктивністьКондуктор"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Змінюємо дані рядка
                    string newactivityKond = Convert.ToString(comboBoxActivityKond.SelectedItem?.ToString());
                    // Перевірка, чи дані змінилися
                    if (newactivityKond == activityKondToUpdateToUpdate)
                    {
                        MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }




                    // Виконуємо запит для зміни рядка
                    string updateQuery = "UPDATE Кондуктор SET АктивністьКондуктор = @NewactivityKond " +
                                         "WHERE Ном_Робіт_Кондуктор = @NomKondToUpdate";

                    using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів та нових значень
                        command.Parameters.AddWithValue("@NomKondToUpdate", nomKondToUpdate);
                        command.Parameters.AddWithValue("@NewactivityKond", newactivityKond);


                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після зміни
                        RefreshDataGrid(dataGridViewKond);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }
        //метод поиска 
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Кондуктор where convert(nvarchar(max), Ном_Робіт_Кондуктор) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormKond formKond = new FormKond();

            // Виклик методу Show() для відображення нової форми
            formKond.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewKond);
        }

        private void FormKondActivityKond_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewKond);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNomKond.Text = "";
        }

        private void dataGridViewKond_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewKond.Rows[selectedRow];

                textBoxNomKond.Text = row.Cells[0].Value.ToString();
                comboBoxActivityKond.Text = row.Cells[1].Value.ToString();

            }
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }
    }
    
}
