﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursova_1.Forms.KondForms
{
    public partial class FormKond : Form
    {
        public FormKond()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            Welcome welcomeForm = new Welcome();

            // Відображення форми Welcome
            welcomeForm.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonKond_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormKondActivityKond formKondActivityKond = new FormKondActivityKond();

            // Відображення форми Welcome
            formKondActivityKond.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonKondZmina_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormKondZmina formKondZmina = new FormKondZmina();

            // Відображення форми Welcome
            formKondZmina.Show();

            // Закриття поточної форми
            this.Close();
        }
    }
}
