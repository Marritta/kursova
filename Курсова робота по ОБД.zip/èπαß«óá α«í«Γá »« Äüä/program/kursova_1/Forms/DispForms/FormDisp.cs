﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kursova_1.Forms.DispForms
{
    public partial class FormDisp : Form
    {
        DataBase dataBase = new DataBase();
        public FormDisp()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            Welcome welcomeForm = new Welcome();

            // Відображення форми Welcome
            welcomeForm.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonPlanMarsh_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormDispPlanMarsh formDispPlanMarshp = new FormDispPlanMarsh();

            // Виклик методу Show() для відображення нової форми
            formDispPlanMarshp.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void buttonZmina_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormDispZmin formDispZmin = new FormDispZmin();

            // Виклик методу Show() для відображення нової форми
            formDispZmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }
    }
}
