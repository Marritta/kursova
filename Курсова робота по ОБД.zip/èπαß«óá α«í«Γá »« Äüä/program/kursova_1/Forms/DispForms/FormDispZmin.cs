﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using kursova_1.Forms.KondForms;
using kursova_1.Forms.VodForms;

namespace kursova_1.Forms.DispForms
{
    public partial class FormDispZmin : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormDispZmin()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;//форма по центру экр
            comboBoxDatePlan.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNomMarsh.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNomAvt.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNomZmina.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNomVod.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNomKond.DropDownStyle = ComboBoxStyle.DropDownList;

            LoadShiftsToComboBox();
            FillComboBoxes(comboBoxDatePlan, comboBoxNomMarsh, comboBoxNomAvt, comboBoxNomVod, comboBoxNomKond);
        }
        private void LoadShiftsToComboBox()
        {
            // Загружаем смены в ComboBox
            for (int i = 1; i <= 2; i++) // предполагаем, что у вас всего 2 смены
            {
                comboBoxNomZmina.Items.Add(i);
            }
        }
        private void FillComboBoxes(ComboBox comboBox1, ComboBox comboBox2, ComboBox comboBox3, ComboBox comboBox4, ComboBox comboBox5)
        {
            try
            {
                dataBase.openConnection();

                // Запрос для первого комбобокса
                string query1 = "SELECT DISTINCT ДатаПлан FROM ПланМаршрути";
                SqlCommand cmd1 = new SqlCommand(query1, dataBase.GetConnection());
                SqlDataReader reader1 = cmd1.ExecuteReader();

                // Очищаем комбобокс перед заполнением
                comboBox1.Items.Clear();

                // Заполняем первый комбобокс
                while (reader1.Read())
                {
                    comboBox1.Items.Add(reader1["ДатаПлан"].ToString());
                }

                // Закрываем первый ридер
                reader1.Close();

                // Запрос для второго комбобокса
                string query2 = "SELECT DISTINCT Номер_марш FROM ПланМаршрути";
                SqlCommand cmd2 = new SqlCommand(query2, dataBase.GetConnection());
                SqlDataReader reader2 = cmd2.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox2.Items.Clear();

                // Заполняем второй комбобокс
                while (reader2.Read())
                {
                    comboBox2.Items.Add(reader2["Номер_марш"].ToString());
                }

                // Закрываем второй ридер
                reader2.Close();

                // Запрос для второго комбобокса
                string query3 = "SELECT Держ_номер_А FROM Автобуси where АктивністьАвт=1";
                SqlCommand cmd3 = new SqlCommand(query3, dataBase.GetConnection());
                SqlDataReader reader3 = cmd3.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox3.Items.Clear();

                // Заполняем второй комбобокс
                while (reader3.Read())
                {
                    comboBox3.Items.Add(reader3["Держ_номер_А"].ToString());
                }

                // Закрываем второй ридер
                reader3.Close();

                // Запрос для второго комбобокса
                string query4 = "SELECT Ном_Робіт_Водій FROM Водій where АктивністьВодій=1";
                SqlCommand cmd4 = new SqlCommand(query4, dataBase.GetConnection());
                SqlDataReader reader4 = cmd4.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox4.Items.Clear();

                // Заполняем второй комбобокс
                while (reader4.Read())
                {
                    comboBox4.Items.Add(reader4["Ном_Робіт_Водій"].ToString());
                }

                // Закрываем второй ридер
                reader4.Close();

                // Запрос для второго комбобокса
                string query5 = "SELECT Ном_Робіт_Кондуктор FROM Кондуктор where АктивністьКондуктор=1";
                SqlCommand cmd5 = new SqlCommand(query5, dataBase.GetConnection());
                SqlDataReader reader5 = cmd5.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox5.Items.Clear();

                // Заполняем второй комбобокс
                while (reader5.Read())
                {
                    comboBox5.Items.Add(reader5["Ном_Робіт_Кондуктор"].ToString());
                }

                // Закрываем второй ридер
                reader5.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении комбобоксов: " + ex.Message);
            }
            finally
            {
                dataBase.closeConnection();
            }
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewDispZmin.Columns.Add("ДатаПлан", "Дата Плану");
            dataGridViewDispZmin.Columns.Add("Номер_марш", "Номер маршруту");
            dataGridViewDispZmin .Columns.Add("Держ_номер_А", "Державний номер автобусу");
            dataGridViewDispZmin.Columns.Add("Номер_Зміни", "Номер зміни");
            dataGridViewDispZmin.Columns.Add("Ном_Робіт_Водій", "Номер Водія");
            dataGridViewDispZmin.Columns.Add("Ном_Робіт_Кондуктор", "Номер Кондуктора");
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormDisp formDisp = new FormDisp();

            formDisp.Show();

            this.Close();
        }

        private void dataGridViewDispZmin_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewDispZmin.Rows[selectedRow];

                comboBoxDatePlan.Text = row.Cells[0].Value.ToString();
                comboBoxNomMarsh.Text = row.Cells[1].Value.ToString();
                comboBoxNomAvt.Text = row.Cells[2].Value.ToString();
                comboBoxNomZmina.Text = row.Cells[3].Value.ToString();
                comboBoxNomVod.Text = row.Cells[4].Value.ToString();
                comboBoxNomKond.Text = row.Cells[5].Value.ToString(); 

            }
        }

        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetDateTime(0), record.GetInt32(1), record.GetString(2), record.GetInt32(3), record.GetInt32(4), record.GetInt32(5));
        }

        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select ДатаПлан,Номер_марш,Держ_номер_А,Номер_Зміни,Ном_Робіт_Водій,Ном_Робіт_Кондуктор from Зміна";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            string dateplStr = comboBoxDatePlan.SelectedItem?.ToString(); ;
            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString(); ;
            string nomAvt = comboBoxNomAvt.SelectedItem?.ToString(); ;
            string nomZminStr = comboBoxNomZmina.SelectedItem?.ToString(); ;
            string nomVodStr = comboBoxNomVod.SelectedItem?.ToString(); ;
            string nomKondStr = comboBoxNomKond.SelectedItem?.ToString(); ;

            DateTime datepl= DateTime.Parse(dateplStr);
            int nomMarsh = int.Parse(nomMarshStr);
            int nomZmin = int.Parse(nomZminStr);
            int nomVod = int.Parse(nomVodStr);
            int nomKond = int.Parse(nomKondStr);


                if (RowExists(datepl, nomMarsh, nomAvt, nomZmin))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }


                if (!ParentKeySkladenExists(datepl, nomMarsh))
                {
                    MessageBox.Show("Такого плану не існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                // Проверка на существование водителя на выбранной дате и смене
                if (VodExistsOnShift(datepl, nomZmin, nomVod))
                {
                    MessageBox.Show("Цей водій вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                // Проверка на существование кондуктора на выбранной дате и смене
                if (KondExistsOnShift(datepl, nomZmin, nomKond))
                {
                    MessageBox.Show("Цей кондуктор вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                // Проверка на существование автобуса на выбранной дате и смене
                if (AvtExistsOnShift(datepl, nomZmin, nomAvt))
                {
                    MessageBox.Show("Цей автобус вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

            var addQuery = $"insert into Зміна(ДатаПлан,Номер_марш,Держ_номер_А,Номер_Зміни,Ном_Робіт_Водій,Ном_Робіт_Кондуктор) values (@DatePlan, @NomMarsh,@NomAvt,@NomZmin,@NomVod,@NomKond)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@DatePlan", datepl);
                    command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                    command.Parameters.AddWithValue("@NomAvt", nomAvt);
                    command.Parameters.AddWithValue("@NomZmin", nomZmin);
                    command.Parameters.AddWithValue("@NomVod", nomVod);
                    command.Parameters.AddWithValue("@NomKond", nomKond);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewDispZmin);


            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(DateTime datepl, int nomMarsh, string nomAvt, int nomZmin)
        {
            var checkQuery = $"select count(*) from Зміна where ДатаПлан = @DatePlan and Номер_марш = @NomMarsh and Держ_номер_А = @NomAvt and Номер_Зміни = @NomZmin";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                command.Parameters.AddWithValue("@NomAvt", nomAvt);
                command.Parameters.AddWithValue("@NomZmin", nomZmin);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        private bool ParentKeySkladenExists(DateTime datepl, int nomMarsh)
        {
            var checkQuery = $"select count(*) from ПланМаршрути WHERE ДатаПлан = @DatePlan and Номер_марш =@NomMarsh";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private bool VodExistsOnShift(DateTime datepl, int nomZmin, int nomVod)
        {
            var checkQuery = $"select count(*) from Зміна where ДатаПлан = @DatePlan and Номер_Зміни = @NomZmin and Ном_Робіт_Водій = @NomVod ";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomZmin", nomZmin);
                command.Parameters.AddWithValue("@NomVod", nomVod);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private bool KondExistsOnShift(DateTime datepl, int nomZmin, int nomKond)
        {
            var checkQuery = $"select count(*) from Зміна where ДатаПлан = @DatePlan and Номер_Зміни = @NomZmin and Ном_Робіт_Кондуктор = @NomKond ";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomZmin", nomZmin);
                command.Parameters.AddWithValue("@NomKond", nomKond);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private bool AvtExistsOnShift(DateTime datepl, int nomZmin, string nomAvt)
        {
            var checkQuery = $"select count(*) from Зміна where ДатаПлан = @DatePlan and Номер_Зміни = @NomZmin and Держ_номер_А = @NomAvt ";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomZmin", nomZmin);
                command.Parameters.AddWithValue("@NomAvt", nomAvt);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Зміна where convert(nvarchar(max), ДатаПлан) + convert(nvarchar(max), Номер_марш) + convert(nvarchar(max), Держ_номер_А)" +
                $"+ convert(nvarchar(max), Номер_Зміни)+ convert(nvarchar(max), Ном_Робіт_Водій)+ convert(nvarchar(max), Ном_Робіт_Кондуктор) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        private void deleteRow()
        {
            if (dataGridViewDispZmin.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                string dateToDeleteStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["ДатаПлан"].Value);
                string nomMarshToDeleteStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Номер_марш"].Value);
                string nomAToDelete = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Держ_номер_А"].Value);
                string nomZminToDeleteStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Номер_Зміни"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    DateTime datepl = DateTime.Parse(dateToDeleteStr);
                    int nomMarsh = int.Parse(nomMarshToDeleteStr);
                    int nomZmin = int.Parse(nomZminToDeleteStr);
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE FROM Зміна WHERE ДатаПлан = @DateToDelete AND Номер_марш = @NomToDelete and Держ_номер_А =@NomAvtToDelete and Номер_Зміни = @NomZminToDelete";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@DateToDelete", datepl);
                        command.Parameters.AddWithValue("@NomToDelete", nomMarsh);
                        command.Parameters.AddWithValue("@NomAvtToDelete", nomAToDelete);
                        command.Parameters.AddWithValue("@NomZminToDelete", nomZmin);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewDispZmin);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        //метод изменения рядка
        private void Change()
        {
           /* string dateplStr = comboBoxDatePlan.SelectedItem?.ToString(); 
            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString(); 
            string nomAvt = comboBoxNomAvt.SelectedItem?.ToString(); 
            string nomZminStr = comboBoxNomZmina.SelectedItem?.ToString();
            string nomVodStr = comboBoxNomVod.SelectedItem?.ToString(); 
            string nomKondStr = comboBoxNomKond.SelectedItem?.ToString(); */


                if (dataGridViewDispZmin.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                // Отримуємо значення ключів для зміни рядка
                string dateToUpdateStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["ДатаПлан"].Value);
                string nomMarshToUpdateStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Номер_марш"].Value);
                string nomAToUpdate = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Держ_номер_А"].Value);
                string nomZminToUpdateStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Номер_Зміни"].Value);

                string nomVodUpdateStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Ном_Робіт_Водій"].Value);
                string nomKondToUpdateStr = Convert.ToString(dataGridViewDispZmin.SelectedRows[0].Cells["Ном_Робіт_Кондуктор"].Value);

                DateTime dateplToUpdate = DateTime.Parse(dateToUpdateStr);
                int nomMarshToUpdate = int.Parse(nomMarshToUpdateStr);
                int nomZminToUpdate = int.Parse(nomZminToUpdateStr);
                int nomVodToUpdate = int.Parse(nomVodUpdateStr);
                int nomKondToUpdate = int.Parse(nomKondToUpdateStr);
                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                {
                    string newdateplStr = Convert.ToString(comboBoxDatePlan.SelectedItem?.ToString());
                    string newnomMarshStr = Convert.ToString(comboBoxNomMarsh.SelectedItem?.ToString());
                    string newnomAvt = Convert.ToString(comboBoxNomAvt.SelectedItem?.ToString());
                    string newnomZminStr = Convert.ToString(comboBoxNomZmina.SelectedItem?.ToString());
                    string newnomVodStr = Convert.ToString(comboBoxNomVod.SelectedItem?.ToString());
                    string newnomKondStr = Convert.ToString(comboBoxNomKond.SelectedItem?.ToString());

                    // Змінюємо дані рядка
                    DateTime newdatepl = DateTime.Parse(newdateplStr);
                    int newnomMarsh = int.Parse(newnomMarshStr);
                    int newnomZmin = int.Parse(newnomZminStr);
                    int newnomVod = int.Parse(newnomVodStr);
                    int newnomKond = int.Parse(newnomKondStr);

                    // Перевірка, чи дані змінилися
                    if (newdateplStr == dateToUpdateStr &&
                              newnomMarshStr == nomMarshToUpdateStr &&
                             newnomAvt == nomAToUpdate &&
                             newnomZminStr == nomZminToUpdateStr &&
                            newnomVodStr == nomVodUpdateStr &&
                             newnomKondStr == nomKondToUpdateStr)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        if (RowExists(newdatepl, newnomMarsh, newnomAvt, newnomZmin) && (newdateplStr != dateToUpdateStr ||
                              newnomMarshStr != nomMarshToUpdateStr ||
                             newnomAvt != nomAToUpdate ||
                             newnomZminStr != nomZminToUpdateStr))
                        {
                            MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }


                        if (!ParentKeySkladenExists(newdatepl, newnomMarsh))
                        {
                            MessageBox.Show("Такого плану не існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                    // Проверка на существование водителя на выбранной дате и смене
                    if (newdatepl != dateplToUpdate || newnomZmin != nomZminToUpdate || newnomVod != nomVodToUpdate)
                    {
                        // Проверка на существование водителя на выбранной дате и смене
                        if (VodExistsOnShift(newdatepl, newnomZmin, newnomVod))
                        {
                            MessageBox.Show("Цей водій вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                    }

                    // Проверка на существование кондуктора на выбранной дате и смене
                    if (newdatepl != dateplToUpdate || newnomZmin != nomZminToUpdate || newnomKond != nomKondToUpdate)
                    {
                        // Проверка на существование кондуктора на выбранной дате и смене
                        if (KondExistsOnShift(newdatepl, newnomZmin, newnomKond))
                        {
                            MessageBox.Show("Цей кондуктор вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                    }


                    // Проверка на существование автобуса на выбранной дате и смене
                    if (newdatepl != dateplToUpdate || newnomZmin != nomZminToUpdate || newnomAvt != nomAToUpdate)
                    {
                        // Проверка на существование автобуса на выбранной дате и смене
                        if (AvtExistsOnShift(newdatepl, newnomZmin, newnomAvt))
                        {
                            MessageBox.Show("Цей автобус вже працює на зміні.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                    }


                    // Виконуємо запит для зміни рядка
                    string updateQuery = "UPDATE Зміна SET " +
                                             "ДатаПлан = @NewDatePlan, " +
                                             "Номер_марш = @NewNomMarsh, " +
                                             "Держ_номер_А = @NewNomAvt, " +
                                             "Номер_Зміни = @NewNomZmin, " +
                                             "Ном_Робіт_Водій = @NewNomVod, " +
                                             "Ном_Робіт_Кондуктор = @NewNomKond " +
                                             "WHERE ДатаПлан = @DatePlanToUpdate and Номер_марш = @NomMarshToUpdate and Держ_номер_А = @NomAvtToUpdate and Номер_Зміни = @NomZminToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                        // Додаємо параметри для значень ключів та нових значень
                        command.Parameters.AddWithValue("@DatePlanToUpdate", dateplToUpdate);
                        command.Parameters.AddWithValue("@NomMarshToUpdate", nomMarshToUpdate);
                        command.Parameters.AddWithValue("@NomAvtToUpdate", nomAToUpdate);
                        command.Parameters.AddWithValue("@NomZminToUpdate", nomZminToUpdate);
                        command.Parameters.AddWithValue("@NewDatePlan", newdatepl);
                        command.Parameters.AddWithValue("@NewNomMarsh", newnomMarsh);
                        command.Parameters.AddWithValue("@NewNomAvt", newnomAvt);
                        command.Parameters.AddWithValue("@NewNomZmin", newnomZmin);
                        command.Parameters.AddWithValue("@NewNomVod", newnomVod);
                        command.Parameters.AddWithValue("@NewNomKond", newnomKond);
                        command.ExecuteNonQuery();



                        command.ExecuteNonQuery();


                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewDispZmin);
                        }
                    }
                    dataBase.closeConnection();
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

        }
        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void FormDispZmin_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewDispZmin);
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewDispZmin);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            comboBoxDatePlan.Text = "";
            comboBoxNomAvt.Text = "";
            comboBoxNomKond.Text = "";
            comboBoxNomMarsh.Text = "";
            comboBoxNomVod.Text = "";
            comboBoxNomZmina.Text = "";
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewDispZmin);
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }
    }

}
