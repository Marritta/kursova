﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace kursova_1.Forms.DispForms
{
    public partial class FormDispPlanMarsh : Form
    {
        DataBase dataBase = new DataBase();

        int selectedRow;
        public FormDispPlanMarsh()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;//форма по центру экр
            comboBoxNomMarsh.DropDownStyle = ComboBoxStyle.DropDownList;
            FillComboBoxes(comboBoxNomMarsh);
        }
        private void FillComboBoxes(ComboBox comboBox1)
        {
            try
            {
                dataBase.openConnection();


                string query1 = "SELECT * FROM Маршрути where АктивністьМарш=1";

                SqlCommand cmd1 = new SqlCommand(query1, dataBase.GetConnection());
                SqlDataReader reader1 = cmd1.ExecuteReader();

                // Очищаем комбобокс перед заполнением
                comboBox1.Items.Clear();

                // Заполняем первый комбобокс 
                while (reader1.Read())
                {
                    // Преобразовываем int в строку и добавляем в комбобокс
                    comboBox1.Items.Add(reader1["Номер_марш"].ToString());
                }

                // Закрываем первый ридер
                reader1.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении комбобоксов: " + ex.Message);
            }
            finally
            {

                dataBase.closeConnection();
            }
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewPlanMarsh.Columns.Add("ДатаПлан", "Дата Плану");
            dataGridViewPlanMarsh.Columns.Add("Номер_марш", "Номер маршруту");
            dataGridViewPlanMarsh.Columns.Add("Планова_кільк_рейсів", "Планова кількість рейсів");
        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw,  IDataRecord record)
        {
            dgw.Rows.Add(record.GetDateTime(0), record.GetInt32(1), record.GetInt32(2));
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from ПланМаршрути";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader(); 
            
            while (reader.Read()) 
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        
        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            DateTime datepl;
            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString(); ;
            int kilkpl;

            if (DateTime.TryParse(textBoxDatePlan.Text, out datepl) && int.TryParse(textBoxPlanKilkReys.Text, out kilkpl))
            {
                int nomMarsh = int.Parse(nomMarshStr);

                if (RowExists(datepl, nomMarsh))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }


                if (kilkpl <= 0)
                {
                    MessageBox.Show("Кількість рейсів має бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }



                var addQuery = $"insert into ПланМаршрути(ДатаПлан,Номер_марш,Планова_кільк_рейсів) values (@DatePlan, @NomMarsh, @Kilkpl)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@DatePlan", datepl);
                    command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                    command.Parameters.AddWithValue("@Kilkpl", kilkpl);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewPlanMarsh);
            }
            else
            {
                MessageBox.Show("Введено некоректні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(DateTime datepl, int nomMarsh)
        {
            var checkQuery = $"select count(*) from ПланМаршрути where ДатаПлан = @DatePlan and Номер_марш = @NomMarsh";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@DatePlan", datepl);
                command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
 
        //метод поиска 
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from ПланМаршрути where convert(nvarchar(max), ДатаПлан) + convert(nvarchar(max), Номер_марш) + convert(nvarchar(max), Планова_кільк_рейсів) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }


        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewPlanMarsh.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                DateTime dateToDelete = Convert.ToDateTime(dataGridViewPlanMarsh.SelectedRows[0].Cells["ДатаПлан"].Value);
                string nomMarshStr = Convert.ToString(dataGridViewPlanMarsh.SelectedRows[0].Cells["Номер_марш"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int nomMarsh = int.Parse(nomMarshStr);
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE FROM ПланМаршрути WHERE ДатаПлан = @DateToDelete AND Номер_марш = @NomToDelete";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@DateToDelete", dateToDelete);
                        command.Parameters.AddWithValue("@NomToDelete", nomMarsh);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewPlanMarsh);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        //метод изменения рядка
        private void Change()
        {
            DateTime datepl;
            int  kilkpl;
            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString();
            if (!DateTime.TryParse(textBoxDatePlan.Text, out datepl)  || !int.TryParse(textBoxPlanKilkReys.Text, out kilkpl))
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dataGridViewPlanMarsh.SelectedRows.Count > 0)
            {
                dataBase.openConnection();
                // Отримуємо значення ключів для зміни рядка
                DateTime dateToUpdate = Convert.ToDateTime(dataGridViewPlanMarsh.SelectedRows[0].Cells["ДатаПлан"].Value);
                string nomMarshStrToUpdate = Convert.ToString(dataGridViewPlanMarsh.SelectedRows[0].Cells["Номер_марш"].Value);

                int nomMarshToUpdate = int.Parse(nomMarshStrToUpdate);
                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Змінюємо дані рядка
                    DateTime newDate = Convert.ToDateTime(textBoxDatePlan.Text);
                    string newnomMarshStr = Convert.ToString(comboBoxNomMarsh.SelectedItem?.ToString());
                    int newKilkpl = Convert.ToInt32(textBoxPlanKilkReys.Text);

                    int newnomMarsh = int.Parse(newnomMarshStr);
                    // Перевірка, чи дані змінилися
                    if (newDate == dateToUpdate && newnomMarshStr == nomMarshStrToUpdate && newKilkpl == Convert.ToInt32(dataGridViewPlanMarsh.SelectedRows[0].Cells["Планова_кільк_рейсів"].Value))
                    {
                        MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                        // Валідація даних
                        if (newKilkpl <= 0)
                    {
                        MessageBox.Show("Кількість рейсів має бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Перевірка на дублікат
                    if (RowExists(newDate, newnomMarsh) && (newDate != dateToUpdate || newnomMarshStr != nomMarshStrToUpdate))
                    {
                        MessageBox.Show("Неможливо змінити рядок. Такий план маршруту вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


                    // Виконуємо запит для зміни рядка
                    string updateQuery = "UPDATE ПланМаршрути SET ДатаПлан = @NewDate, Номер_марш = @NewNom, Планова_кільк_рейсів = @NewKilkpl " +
                                         "WHERE ДатаПлан = @DateToUpdate AND Номер_марш = @NomToUpdate";

                    using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів та нових значень
                        command.Parameters.AddWithValue("@DateToUpdate", dateToUpdate);
                        command.Parameters.AddWithValue("@NomToUpdate", nomMarshToUpdate);
                        command.Parameters.AddWithValue("@NewDate", newDate);
                        command.Parameters.AddWithValue("@NewNom", newnomMarsh);
                        command.Parameters.AddWithValue("@NewKilkpl", newKilkpl);

                        
                        command.ExecuteNonQuery();
                        

                        MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після зміни
                        RefreshDataGrid(dataGridViewPlanMarsh);
                    }
                }
                dataBase.closeConnection();
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        //линк лейбл возвращение на предидущ. форму
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormDisp formDisp = new FormDisp();

            formDisp.Show();

            this.Close();
        }
        //в форме создаем таблицу
        private void FormDispPlanMarsh_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewPlanMarsh);
        }
        //все значения кликнутого кортежа запис. в текст боксы
        private void dataGridViewPlanMarsh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewPlanMarsh.Rows[selectedRow];

                textBoxDatePlan.Text = row.Cells[0].Value.ToString();
                comboBoxNomMarsh.Text = row.Cells[1].Value.ToString();
                textBoxPlanKilkReys.Text = row.Cells[2].Value.ToString();

            }
        }
        //рефреш таблицы
        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewPlanMarsh);
        }
        //рефреш текст боксов
        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxDatePlan.Text = "";
            comboBoxNomMarsh.Text = "";
            textBoxPlanKilkReys.Text = "";
        }
        //после клика вызываем метод сохранения нового кортежа
        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }
        //текст бокс поиска
        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewPlanMarsh);
        }
        //кнопка удаления
        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();

        }
        //кнопка изменения
        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }
    }
}
