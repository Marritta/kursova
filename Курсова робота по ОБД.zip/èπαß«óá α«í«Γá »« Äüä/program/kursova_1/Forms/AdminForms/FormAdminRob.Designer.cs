﻿namespace kursova_1.Forms.AdminForms
{
    partial class FormAdminRob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.dataGridViewAdminRob = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonSaveNewRow = new System.Windows.Forms.Button();
            this.buttonUpdateZapis = new System.Windows.Forms.Button();
            this.buttonDeleteZapis = new System.Windows.Forms.Button();
            this.buttonRefreshDani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNomRob = new System.Windows.Forms.TextBox();
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.comboBoxPosada = new System.Windows.Forms.ComboBox();
            this.textBoxDatePrNaRob = new System.Windows.Forms.TextBox();
            this.textBoxPhoneDom = new System.Windows.Forms.TextBox();
            this.textBoxPhoneRob = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxBirthDate = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxPibRob = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminRob)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 59);
            this.panel1.TabIndex = 2;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(531, 18);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(71, 20);
            this.buttonRefresh.TabIndex = 3;
            this.buttonRefresh.Text = "Оновити";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(628, 18);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(129, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Робітники";
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(749, 18);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 3;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // dataGridViewAdminRob
            // 
            this.dataGridViewAdminRob.AllowUserToAddRows = false;
            this.dataGridViewAdminRob.AllowUserToDeleteRows = false;
            this.dataGridViewAdminRob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdminRob.Location = new System.Drawing.Point(12, 110);
            this.dataGridViewAdminRob.Name = "dataGridViewAdminRob";
            this.dataGridViewAdminRob.Size = new System.Drawing.Size(776, 245);
            this.dataGridViewAdminRob.TabIndex = 4;
            this.dataGridViewAdminRob.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAdminRob_CellClick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.buttonSaveNewRow);
            this.panel3.Controls.Add(this.buttonUpdateZapis);
            this.panel3.Controls.Add(this.buttonDeleteZapis);
            this.panel3.Controls.Add(this.buttonRefreshDani);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(610, 370);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 169);
            this.panel3.TabIndex = 7;
            // 
            // buttonSaveNewRow
            // 
            this.buttonSaveNewRow.Location = new System.Drawing.Point(24, 64);
            this.buttonSaveNewRow.Name = "buttonSaveNewRow";
            this.buttonSaveNewRow.Size = new System.Drawing.Size(131, 23);
            this.buttonSaveNewRow.TabIndex = 4;
            this.buttonSaveNewRow.Text = "Зберегти новий запис";
            this.buttonSaveNewRow.UseVisualStyleBackColor = true;
            this.buttonSaveNewRow.Click += new System.EventHandler(this.buttonSaveNewRow_Click);
            // 
            // buttonUpdateZapis
            // 
            this.buttonUpdateZapis.Location = new System.Drawing.Point(24, 122);
            this.buttonUpdateZapis.Name = "buttonUpdateZapis";
            this.buttonUpdateZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonUpdateZapis.TabIndex = 3;
            this.buttonUpdateZapis.Text = "Змінити";
            this.buttonUpdateZapis.UseVisualStyleBackColor = true;
            this.buttonUpdateZapis.Click += new System.EventHandler(this.buttonUpdateZapis_Click);
            // 
            // buttonDeleteZapis
            // 
            this.buttonDeleteZapis.Location = new System.Drawing.Point(24, 93);
            this.buttonDeleteZapis.Name = "buttonDeleteZapis";
            this.buttonDeleteZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonDeleteZapis.TabIndex = 2;
            this.buttonDeleteZapis.Text = "Видалити";
            this.buttonDeleteZapis.UseVisualStyleBackColor = true;
            this.buttonDeleteZapis.Click += new System.EventHandler(this.buttonDeleteZapis_Click);
            // 
            // buttonRefreshDani
            // 
            this.buttonRefreshDani.Location = new System.Drawing.Point(24, 35);
            this.buttonRefreshDani.Name = "buttonRefreshDani";
            this.buttonRefreshDani.Size = new System.Drawing.Size(131, 23);
            this.buttonRefreshDani.TabIndex = 1;
            this.buttonRefreshDani.Text = "Очистити дані";
            this.buttonRefreshDani.UseVisualStyleBackColor = true;
            this.buttonRefreshDani.Click += new System.EventHandler(this.buttonRefreshDani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Управління записами";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBoxNomRob);
            this.panel2.Controls.Add(this.comboBoxCategory);
            this.panel2.Controls.Add(this.comboBoxPosada);
            this.panel2.Controls.Add(this.textBoxDatePrNaRob);
            this.panel2.Controls.Add(this.textBoxPhoneDom);
            this.panel2.Controls.Add(this.textBoxPhoneRob);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.textBoxAddress);
            this.panel2.Controls.Add(this.textBoxBirthDate);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textBoxPibRob);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(13, 361);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(556, 189);
            this.panel2.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Номер робітника";
            // 
            // textBoxNomRob
            // 
            this.textBoxNomRob.Location = new System.Drawing.Point(110, 33);
            this.textBoxNomRob.Name = "textBoxNomRob";
            this.textBoxNomRob.Size = new System.Drawing.Size(155, 20);
            this.textBoxNomRob.TabIndex = 24;
            // 
            // comboBoxCategory
            // 
            this.comboBoxCategory.FormattingEnabled = true;
            this.comboBoxCategory.Location = new System.Drawing.Point(111, 120);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(156, 21);
            this.comboBoxCategory.TabIndex = 23;
            // 
            // comboBoxPosada
            // 
            this.comboBoxPosada.FormattingEnabled = true;
            this.comboBoxPosada.Location = new System.Drawing.Point(111, 87);
            this.comboBoxPosada.Name = "comboBoxPosada";
            this.comboBoxPosada.Size = new System.Drawing.Size(155, 21);
            this.comboBoxPosada.TabIndex = 22;
            // 
            // textBoxDatePrNaRob
            // 
            this.textBoxDatePrNaRob.Location = new System.Drawing.Point(397, 121);
            this.textBoxDatePrNaRob.Name = "textBoxDatePrNaRob";
            this.textBoxDatePrNaRob.Size = new System.Drawing.Size(156, 20);
            this.textBoxDatePrNaRob.TabIndex = 20;
            // 
            // textBoxPhoneDom
            // 
            this.textBoxPhoneDom.Location = new System.Drawing.Point(397, 92);
            this.textBoxPhoneDom.Name = "textBoxPhoneDom";
            this.textBoxPhoneDom.Size = new System.Drawing.Size(156, 20);
            this.textBoxPhoneDom.TabIndex = 19;
            // 
            // textBoxPhoneRob
            // 
            this.textBoxPhoneRob.Location = new System.Drawing.Point(397, 63);
            this.textBoxPhoneRob.Name = "textBoxPhoneRob";
            this.textBoxPhoneRob.Size = new System.Drawing.Size(156, 20);
            this.textBoxPhoneRob.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(303, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 26);
            this.label13.TabIndex = 17;
            this.label13.Text = "Дата прийняття\r\nна роботу\r\n";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(288, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 13);
            this.label11.TabIndex = 15;
            this.label11.Text = "Телефон домашній\r\n";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(295, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Телефон робочий\r\n";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(398, 33);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(155, 20);
            this.textBoxAddress.TabIndex = 13;
            // 
            // textBoxBirthDate
            // 
            this.textBoxBirthDate.Location = new System.Drawing.Point(111, 149);
            this.textBoxBirthDate.Name = "textBoxBirthDate";
            this.textBoxBirthDate.Size = new System.Drawing.Size(156, 20);
            this.textBoxBirthDate.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(347, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Адреса\r\n";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 155);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Дата народження";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(49, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Категорія";
            // 
            // textBoxPibRob
            // 
            this.textBoxPibRob.Location = new System.Drawing.Point(110, 59);
            this.textBoxPibRob.Name = "textBoxPibRob";
            this.textBoxPibRob.Size = new System.Drawing.Size(156, 20);
            this.textBoxPibRob.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(60, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Посада";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дані:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ПІБ робітника";
            // 
            // FormAdminRob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dataGridViewAdminRob);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.panel1);
            this.Name = "FormAdminRob";
            this.Text = "FormAdminRob";
            this.Load += new System.EventHandler(this.FormAdminRob_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminRob)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.DataGridView dataGridViewAdminRob;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonSaveNewRow;
        private System.Windows.Forms.Button buttonUpdateZapis;
        private System.Windows.Forms.Button buttonDeleteZapis;
        private System.Windows.Forms.Button buttonRefreshDani;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TextBox textBoxBirthDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxPibRob;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxDatePrNaRob;
        private System.Windows.Forms.TextBox textBoxPhoneDom;
        private System.Windows.Forms.TextBox textBoxPhoneRob;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.ComboBox comboBoxPosada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNomRob;
        private System.Windows.Forms.Label label4;
    }
}