﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Reflection;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdminRob : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormAdminRob()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxPosada.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxCategory.DropDownStyle = ComboBoxStyle.DropDownList;

            FillComboBoxes(comboBoxPosada, comboBoxCategory);
        }
        private void FillComboBoxes(ComboBox comboBox1, ComboBox comboBox2)
        {
            try
            {
                dataBase.openConnection();

                // Запрос для первого комбобокса
                string query1 = "SELECT DISTINCT Посада FROM Оклад";
                SqlCommand cmd1 = new SqlCommand(query1, dataBase.GetConnection());
                SqlDataReader reader1 = cmd1.ExecuteReader();

                // Очищаем комбобокс перед заполнением
                comboBox1.Items.Clear();

                // Заполняем первый комбобокс
                while (reader1.Read())
                {
                    comboBox1.Items.Add(reader1["Посада"].ToString());
                }

                // Закрываем первый ридер
                reader1.Close();

                // Запрос для второго комбобокса
                string query2 = "SELECT DISTINCT Категорія FROM Оклад";
                SqlCommand cmd2 = new SqlCommand(query2, dataBase.GetConnection());
                SqlDataReader reader2 = cmd2.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox2.Items.Clear();

                // Заполняем второй комбобокс
                while (reader2.Read())
                {
                    comboBox2.Items.Add(reader2["Категорія"].ToString());
                }

                // Закрываем второй ридер
                reader2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении комбобоксов: " + ex.Message);
            }
            finally
            {
                dataBase.closeConnection();
            }
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewAdminRob.Columns.Add("Ном_Робіт", "Номер робітника");
            dataGridViewAdminRob.Columns.Add("ПІБ_Роб", "ПІБ Робітника");
            dataGridViewAdminRob.Columns.Add("Посада", "Посада");
            dataGridViewAdminRob.Columns.Add("Категорія", "Категорія");
            dataGridViewAdminRob.Columns.Add("Дата_народж", "Дата народження");
            dataGridViewAdminRob.Columns.Add("Адреса", "Адреса");
            dataGridViewAdminRob.Columns.Add("Тел_роб", "Тел. робочий");
            dataGridViewAdminRob.Columns.Add("Тел_дом", "Тел. домашній");
            dataGridViewAdminRob.Columns.Add("Дата_прийнят_на_роб", "Дата прийняття на роботу");
            dataGridViewAdminRob.Columns.Add("ДатаЗвільн", "Дата звільнення");
        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetDateTime(4),
            record.GetString(5), record.GetString(6), record.GetString(7), record.GetDateTime(8), record.IsDBNull(9) ? (DateTime?)null : record.GetDateTime(9));
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Робітник";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            int nomRob;
            string pibRob = textBoxPibRob.Text;
            string posada = comboBoxPosada.SelectedItem?.ToString();
            string category = comboBoxCategory.SelectedItem?.ToString();
            DateTime dataNarodj;
            string address = textBoxAddress.Text;
            string phoneRob =textBoxPhoneRob.Text;

            string phoneDom = textBoxPhoneDom.Text;
            DateTime dataPriynyat;
            

            if (int.TryParse(textBoxNomRob.Text, out nomRob)  && DateTime.TryParse(textBoxBirthDate.Text, out dataNarodj) && DateTime.TryParse(textBoxDatePrNaRob.Text, out dataPriynyat)
                 && phoneDom.All(char.IsDigit) && phoneRob.All(char.IsDigit))
            {
                

                if (RowExists(nomRob))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                if (!ParentKeyExists(posada, category))
                {
                    MessageBox.Show("Не існує такої категорії для даної посади.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (nomRob <= 0)
                {
                    MessageBox.Show("Номер робітника повинен бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                if (pibRob.Length > 50)
                {
                    MessageBox.Show("Недопустима кількість символів ПІБ (максимум 50).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                if (address.Length > 60)
                {
                    MessageBox.Show("Недопустима кількість символів для Адреси (максимум 60).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (phoneRob.Length > 12 || phoneDom.Length > 12)
                {
                    MessageBox.Show("Недопустима кількість символів для номеру телефона (максимум 12).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                var addQuery = $"insert into Робітник(Ном_Робіт,ПІБ_Роб,Посада,Категорія,Дата_народж,Адреса,Тел_роб,Тел_дом,Дата_прийнят_на_роб) " +
                    $"values (@NomRob, @PibRob, @Posada, @Category, @DataNarodj, @Address, @PhoneRob, @PhoneDom, @DataPriynyat)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@NomRob", nomRob);
                    command.Parameters.AddWithValue("@PibRob", pibRob);
                    command.Parameters.AddWithValue("@Posada", posada);
                    command.Parameters.AddWithValue("@Category", category);
                    command.Parameters.AddWithValue("@DataNarodj", dataNarodj);
                    command.Parameters.AddWithValue("@Address", address);
                    command.Parameters.AddWithValue("@PhoneRob", phoneRob);
                    command.Parameters.AddWithValue("@PhoneDom", phoneDom);
                    command.Parameters.AddWithValue("@DataPriynyat", dataPriynyat);
                    



                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewAdminRob);
            }
            else
            {
                MessageBox.Show("Введено некоректні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            dataBase.closeConnection();

        }

        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(int nomRob)
        {
            var checkQuery = $"select count(*) from Робітник where Ном_Робіт = @NomRob";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NomRob", nomRob);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        // метод проверки на существование родительского ключа в таблице
        private bool ParentKeyExists(string posada, string category)
        {
            var checkQuery = $"select count(*) from Оклад where Посада = @Posada and Категорія = @Category";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@Posada", posada);
                command.Parameters.AddWithValue("@Category", category);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        //метод поиска 
             private void Search(DataGridView dgw)
             {
                dgw.Rows.Clear();
                string searchString = $"select * from Робітник where " +
                        "CONVERT(nvarchar(max), Ном_Робіт) + " +
                        "CONVERT(nvarchar(max), ПІБ_Роб) + " +
                        "CONVERT(nvarchar(max), Посада) + " +
                        "CONVERT(nvarchar(max), Категорія) + " +
                        "CONVERT(nvarchar(max), Дата_народж) + " +
                        "CONVERT(nvarchar(max), Адреса) + " +
                        "CONVERT(nvarchar(max), Тел_роб) + " +
                        "CONVERT(nvarchar(max), Тел_дом) + " +
                        "CONVERT(nvarchar(max), Дата_прийнят_на_роб) " +
                    $"like '%{textBoxSearch.Text}%'";

                SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
                dataBase.openConnection();
                SqlDataReader read = com.ExecuteReader();

                while (read.Read())
                {
                    ReadSingleRow(dgw, read);
                }
                read.Close();
             }
  
        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewAdminRob.SelectedRows.Count > 0)
            {
                // Получаем значения ключей для удаления строки
                int nomToDelete = Convert.ToInt32(dataGridViewAdminRob.SelectedRows[0].Cells["Ном_Робіт"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE FROM Робітник WHERE Ном_Робіт = @NomToDelete";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@NomToDelete", nomToDelete);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();


                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewAdminRob);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //метод изменения рядка
        private void Change()
        {
            int nomRob;
            string pibRob = textBoxPibRob.Text;
            string posada = comboBoxPosada.SelectedItem?.ToString();
            string category = comboBoxCategory.SelectedItem?.ToString();
            DateTime dataNarodj;
            string address = textBoxAddress.Text;
            string phoneRob = textBoxPhoneRob.Text;
            string phoneDom = textBoxPhoneDom.Text;
            DateTime dataPriynyat;
            //DateTime dataZviln;

            if (int.TryParse(textBoxNomRob.Text, out nomRob)  && DateTime.TryParse(textBoxBirthDate.Text, out dataNarodj) && DateTime.TryParse(textBoxDatePrNaRob.Text, out dataPriynyat)
                   && phoneDom.All(char.IsDigit) && phoneRob.All(char.IsDigit))
            {

                if (dataGridViewAdminRob.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                    // Отримуємо значення ключів для зміни рядка
                    int nomRobToUpdate = Convert.ToInt32(dataGridViewAdminRob.SelectedRows[0].Cells["Ном_Робіт"].Value);

                    string pibRobToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["ПІБ_Роб"].Value);
                    string posadaToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["Посада"].Value);
                    string categoryToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["Категорія"].Value);
                    DateTime dataNarodjToUpdate = Convert.ToDateTime(dataGridViewAdminRob.SelectedRows[0].Cells["Дата_народж"].Value);
                    string addressToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["Адреса"].Value);
                    string phoneRobToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["Тел_роб"].Value);
                    string phoneDomToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["Тел_дом"].Value);
                    DateTime dataPriynyatToUpdate = Convert.ToDateTime(dataGridViewAdminRob.SelectedRows[0].Cells["Дата_прийнят_на_роб"].Value);
                    //DateTime dataZvilnToUpdate = Convert.ToDateTime(dataGridViewAdminRob.SelectedRows[0].Cells["ДатаЗвільн"].Value);

                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        // Змінюємо дані рядка
                        int newnomRob = Convert.ToInt32(textBoxNomRob.Text);

                        string newpibRob = Convert.ToString(textBoxPibRob.Text);
                        string newposada = Convert.ToString(comboBoxPosada.Text);
                        string newcategory = Convert.ToString(comboBoxCategory.Text);
                        DateTime newdataNarodj = Convert.ToDateTime(textBoxBirthDate.Text);
                        string newaddress = Convert.ToString(textBoxAddress.Text);
                        string newphoneRob = Convert.ToString(textBoxPhoneRob.Text);
                        string newphoneDom = Convert.ToString(textBoxPhoneDom.Text);
                        DateTime newdataPriynyat = Convert.ToDateTime(textBoxDatePrNaRob.Text);
                       // DateTime newdataZviln = Convert.ToDateTime(textBoxDateZvilZRob.Text);

                        //DateTime? newdataZviln;
                        //if (!string.IsNullOrEmpty(textBoxDateZvilZRob.Text) && DateTime.TryParse(textBoxDateZvilZRob.Text, out var parsedDate))
                        //{
                        //    newdataZviln = parsedDate;
                        //}
                        //else
                        //{
                        //    newdataZviln = dataZvilnToUpdate;
                        //}
                        // Перевірка, чи дані змінилися
                        if (newnomRob == nomRobToUpdate &&
                             newpibRob == pibRobToUpdate &&
                             newposada == posadaToUpdate &&
                             newcategory == categoryToUpdate &&
                             newdataNarodj == dataNarodjToUpdate &&
                             newaddress == addressToUpdate &&
                             newphoneRob == phoneRobToUpdate &&
                             newphoneDom == phoneDomToUpdate &&
                             newdataPriynyat == dataPriynyatToUpdate)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        // Валідація даних
                        if (newnomRob <= 0)
                        {
                            MessageBox.Show("Номер робітника повинен бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        if (newpibRob.Length > 50)
                        {
                            MessageBox.Show("Недопустима кількість символів ПІБ (максимум 50).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        if (newaddress.Length > 60)
                        {
                            MessageBox.Show("Недопустима кількість символів для Адреси (максимум 60).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                        if (newphoneRob.Length > 12 || newphoneDom.Length > 12)
                        {
                            MessageBox.Show("Недопустима кількість символів для номеру телефона (максимум 12).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        // Перевірка на дублікат
                        if (RowExists(newnomRob) && (newnomRob != nomRobToUpdate))
                        {
                            MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        // Перевірка на існування батьківського ключа
                        if (!ParentKeyExists(newposada, newcategory))
                        {
                            MessageBox.Show("Не існує такої категорії для даної посади", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }


                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Робітник SET " +
                                             "Ном_Робіт = @NewNomRob, " +
                                             "ПІБ_Роб = @NewPibRob, " +
                                             "Посада = @NewPosada, " +
                                             "Категорія = @NewCategory, " +
                                             "Дата_народж = @NewDataNarodj, " +
                                             "Адреса = @NewAddress, " +
                                             "Тел_роб = @NewPhoneRob, " +
                                             "Тел_дом = @NewPhoneDom, " +
                                             "Дата_прийнят_на_роб = @NewDataPriynyat " +
                                             "WHERE Ном_Робіт = @NomRobToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomRobToUpdate", nomRobToUpdate);
                            command.Parameters.AddWithValue("@NewNomRob", newnomRob);
                            command.Parameters.AddWithValue("@NewPibRob", newpibRob);
                            command.Parameters.AddWithValue("@NewPosada", newposada);
                            command.Parameters.AddWithValue("@NewCategory", newcategory);
                            command.Parameters.AddWithValue("@NewDataNarodj", newdataNarodj);
                            command.Parameters.AddWithValue("@NewAddress", newaddress);
                            command.Parameters.AddWithValue("@NewPhoneRob", newphoneRob);
                            command.Parameters.AddWithValue("@NewPhoneDom", newphoneDom);
                            command.Parameters.AddWithValue("@NewDataPriynyat", newdataPriynyat);
                           // command.Parameters.AddWithValue("@NewDataZviln", newdataZviln);



                            command.ExecuteNonQuery();


                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewAdminRob);
                        }
                    }
                    dataBase.closeConnection();
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void FormAdminRob_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminRob);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNomRob.Text = "";
            textBoxPibRob.Text = "";
            textBoxBirthDate.Text = "";
            textBoxAddress.Text = "";
            textBoxPhoneRob.Text = "";
            textBoxPhoneDom.Text = "";
            textBoxDatePrNaRob.Text = "";
            //textBoxDateZvilZRob.Text = "";

        }

        private void dataGridViewAdminRob_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminRob.Rows[selectedRow];

                textBoxNomRob.Text = GetValueAsString(row.Cells[0].Value);
                textBoxPibRob.Text = GetValueAsString(row.Cells[1].Value);
                comboBoxPosada.Text = GetValueAsString(row.Cells[2].Value);
                comboBoxCategory.Text = GetValueAsString(row.Cells[3].Value);
                textBoxBirthDate.Text = GetValueAsString(row.Cells[4].Value);
                textBoxAddress.Text = GetValueAsString(row.Cells[5].Value);
                textBoxPhoneRob.Text = GetValueAsString(row.Cells[6].Value);
                textBoxPhoneDom.Text = GetValueAsString(row.Cells[7].Value);
                textBoxDatePrNaRob.Text = GetValueAsString(row.Cells[8].Value);
                //textBoxDateZvilZRob.Text = GetValueAsString(row.Cells[9].Value);
            }
        }

        private string GetValueAsString(object value)
        {
            return value?.ToString() ?? string.Empty;
        }


        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminRob);
        }

        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAdminRob);
        }
    }
}
