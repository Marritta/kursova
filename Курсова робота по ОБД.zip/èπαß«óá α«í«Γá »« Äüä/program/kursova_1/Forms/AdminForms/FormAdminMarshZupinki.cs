﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdminMarshZupinki : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormAdminMarshZupinki()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxNomMarsh.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxNazvZup.DropDownStyle = ComboBoxStyle.DropDownList;

            FillComboBoxes(comboBoxNomMarsh, comboBoxNazvZup);
         
        }

        private void FillComboBoxes(ComboBox comboBox1, ComboBox comboBox2)
        {
            try
            {
                dataBase.openConnection();

               
                string query1 = "SELECT * FROM Маршрути";
                string query2 = "SELECT * FROM Зупинки";

                SqlCommand cmd1 = new SqlCommand(query1, dataBase.GetConnection());
                SqlDataReader reader1 = cmd1.ExecuteReader();

                // Очищаем комбобокс перед заполнением
                comboBox1.Items.Clear();

                // Заполняем первый комбобокс 
                while (reader1.Read())
                {
                    // Преобразовываем int в строку и добавляем в комбобокс
                    comboBox1.Items.Add(reader1["Номер_марш"].ToString());
                }

                // Закрываем первый ридер
                reader1.Close();

                // Теперь выполняем второй запрос
                SqlCommand cmd2 = new SqlCommand(query2, dataBase.GetConnection());
                SqlDataReader reader2 = cmd2.ExecuteReader();

                // Очищаем второй комбобокс перед заполнением
                comboBox2.Items.Clear();

                // Заполняем второй комбобокс
                while (reader2.Read())
                {
                    
                    comboBox2.Items.Add(reader2["Назва_Зуп"].ToString());
                }

                // Закрываем второй ридер
                reader2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при заполнении комбобоксов: " + ex.Message);
            }
            finally
            {
              
                dataBase.closeConnection();
            }
        }

        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewAdminMarshZup.Columns.Add("Номер_марш", "Номер маршрута");
            dataGridViewAdminMarshZup.Columns.Add("Назва_Зуп", "Назва зупинки");
            dataGridViewAdminMarshZup.Columns.Add("Ном_Зупинки", "Номер зупинки");
        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetInt32(2));
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from ЗупинкиМаршрут";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString();
            string nazvZup = comboBoxNazvZup.SelectedItem?.ToString();
            int nomZup;

            if (int.TryParse(textBoxNomZup.Text, out nomZup))
            {
                int nomMarsh = int.Parse(nomMarshStr);

                if (RowExists(nomMarsh, nazvZup))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }


                if (nomZup <= 0)
                {
                    MessageBox.Show("Номер зупинки повинен бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }



                var addQuery = $"insert into ЗупинкиМаршрут(Номер_марш,Назва_Зуп,Ном_Зупинки) values (@NomMarsh, @NazvZup, @NomZup)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                    command.Parameters.AddWithValue("@NazvZup", nazvZup);
                    command.Parameters.AddWithValue("@NomZup", nomZup);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewAdminMarshZup);
            }
            else
            {
                MessageBox.Show("Введено некоректні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(int nomMarsh, string nazvZup)
        {
            var checkQuery = $"select count(*) from ЗупинкиМаршрут where Номер_марш = @NomMarsh and Назва_Зуп = @NazvZup";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                command.Parameters.AddWithValue("@NazvZup", nazvZup);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        //метод поиска
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from ЗупинкиМаршрут where convert(nvarchar(max), Номер_марш) + convert(nvarchar(max), Назва_Зуп) + convert(nvarchar(max), Ном_Зупинки) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewAdminMarshZup.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                string nomMarshStr = Convert.ToString(dataGridViewAdminMarshZup.SelectedRows[0].Cells["Номер_марш"].Value);
                string nazvZup = Convert.ToString(dataGridViewAdminMarshZup.SelectedRows[0].Cells["Назва_Зуп"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int nomMarsh = int.Parse(nomMarshStr);
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE from ЗупинкиМаршрут where Номер_марш = @NomMarsh and Назва_Зуп = @NazvZup";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                        command.Parameters.AddWithValue("@NazvZup", nazvZup);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewAdminMarshZup);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //метод изменения рядка
        private void Change()
        {
            string nomMarshStr = comboBoxNomMarsh.SelectedItem?.ToString();
            string nazvZup = comboBoxNazvZup.SelectedItem?.ToString();
            int nomZup;

            if (int.TryParse(textBoxNomZup.Text, out nomZup))
            {
                

                if (dataGridViewAdminMarshZup.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                    // Отримуємо значення ключів для зміни рядка
                    string nomMarshStrToUpdate = Convert.ToString(dataGridViewAdminMarshZup.SelectedRows[0].Cells["Номер_марш"].Value);
                    string nazvZupToUpdate = Convert.ToString(dataGridViewAdminMarshZup.SelectedRows[0].Cells["Назва_Зуп"].Value);

                    int nomZupToUpdate = Convert.ToInt32(dataGridViewAdminMarshZup.SelectedRows[0].Cells["Ном_Зупинки"].Value);

                    int nomMarshToUpdate = int.Parse(nomMarshStrToUpdate);
                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        // Змінюємо дані рядка
                        string newnomMarshStr = Convert.ToString(comboBoxNomMarsh.SelectedItem?.ToString());
                        string newnazvZup = Convert.ToString(comboBoxNazvZup.SelectedItem?.ToString());
                        int newnomZup = Convert.ToInt32(textBoxNomZup.Text);

                        int newnomMarsh = int.Parse(newnomMarshStr);
                        // Перевірка, чи дані змінилися
                        if (newnomMarshStr == nomMarshStrToUpdate && newnazvZup == nazvZupToUpdate && newnomZup == nomZupToUpdate)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        // Валідація даних
                        if (newnomZup <= 0)
                        {
                            MessageBox.Show("Номер зупинки повинен бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        // Перевірка на дублікат
                        if (RowExists(newnomMarsh, newnazvZup) && (newnomMarshStr != nomMarshStrToUpdate || newnazvZup != nazvZupToUpdate))
                        {
                            MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }



                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE ЗупинкиМаршрут SET Номер_марш = @NewnomMarsh, Назва_Зуп = @NewnazvZup, Ном_Зупинки = @NewnomZup " +
                                             "WHERE Номер_марш = @NomMarshToUpdate AND Назва_Зуп = @NazvZupToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomMarshToUpdate", nomMarshToUpdate);
                            command.Parameters.AddWithValue("@NazvZupToUpdate", nazvZupToUpdate);
                            command.Parameters.AddWithValue("@NewnomMarsh", newnomMarsh);
                            command.Parameters.AddWithValue("@NewnazvZup", newnazvZup);
                            command.Parameters.AddWithValue("@NewnomZup", newnomZup);

                            
                            command.ExecuteNonQuery();
                            

                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewAdminMarshZup);
                        }
                    }
                    dataBase.closeConnection();
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void FormAdminMarshZupinki_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminMarshZup);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            comboBoxNomMarsh.Text = "";
            comboBoxNazvZup.Text = "";
            textBoxNomZup.Text = "";
        }

        private void dataGridViewAdminMarshZup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminMarshZup.Rows[selectedRow];

                comboBoxNomMarsh.Text = row.Cells[0].Value.ToString();
                comboBoxNazvZup.Text = row.Cells[1].Value.ToString();
                textBoxNomZup.Text = row.Cells[2].Value.ToString();

            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminMarshZup);
        }

        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAdminMarshZup);
        }
    }
}
