﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlTypes;
using System.Data.SqlClient;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdminAvt : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormAdminAvt()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxActivityAvt.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActivityAvt.Items.AddRange(new object[] { "True", "False" });

        }

        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewAdminAvt.Columns.Add("Держ_номер_А", "Державний номер Автобуса");
            dataGridViewAdminAvt.Columns.Add("Марка_А", "Марка");
            dataGridViewAdminAvt.Columns.Add("Рік_випуск", "Рік випуску");
            dataGridViewAdminAvt.Columns.Add("Пробіг", "Пробіг(на момент придбання)");
            dataGridViewAdminAvt.Columns.Add("АктивністьАвт", "Активність автобуса");

        }

        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetString(0), record.GetString(1), record.GetValue(2), record.GetValue(3), record.GetValue(4));
        }

        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Автобуси";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }

        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            string nomAvt = textBoxDerNomAvt.Text;
            string markAvt = textBoxMarka.Text;
            int yearVipusk;
            int probig;
            string activityAvt = comboBoxActivityAvt.SelectedItem?.ToString(); 


            if (!string.IsNullOrEmpty(activityAvt) && markAvt.All(char.IsLetter) && int.TryParse(textBoxYearVipusk.Text, out yearVipusk) && int.TryParse(textBoxProbig.Text, out probig))
            {


                if (RowExists(nomAvt))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (nomAvt.Length > 8 || markAvt.Length > 20)
                {
                    MessageBox.Show("Недопустима кількість символів. (Держ. ном. авт -максимум 8, Марка авт. -максимум 20).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (probig < 0)
                {
                    MessageBox.Show("Пробіг має бути більше за 0 або 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (yearVipusk < 2000 || yearVipusk >2023)
                {
                    MessageBox.Show("Рік випуску має бути в діапазоні від 2000 до 2023 включно.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                var addQuery = $"insert into Автобуси(Держ_номер_А,Марка_А,Рік_випуск,Пробіг,АктивністьАвт) values (@NomAvt,@MarkAvt,@YearVipusk,@Probig,@ActivityMarsh)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@NomAvt", nomAvt);
                    command.Parameters.AddWithValue("@MarkAvt", markAvt);
                    command.Parameters.AddWithValue("@YearVipusk", yearVipusk);
                    command.Parameters.AddWithValue("@Probig", probig);
                    command.Parameters.AddWithValue("@ActivityMarsh", activityAvt);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewAdminAvt);
            }
            else
            {
                MessageBox.Show("Введено некоректні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(string nomAvt)
        {
            var checkQuery = $"select count(*) from Автобуси where Держ_номер_А = @NomAvt";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NomAvt", nomAvt);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        //метод поиска 
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Автобуси where convert(nvarchar(max), Держ_номер_А) + convert(nvarchar(max), Марка_А) " +
                $"+ convert(nvarchar(max), Рік_випуск) + convert(nvarchar(max), Пробіг)+ convert(nvarchar(max), АктивністьАвт) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewAdminAvt.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                string nomAvt = Convert.ToString (dataGridViewAdminAvt.SelectedRows[0].Cells["Держ_номер_А"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE FROM Автобуси WHERE Держ_номер_А = @NomAvt";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@NomAvt", nomAvt);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewAdminAvt);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //метод изменения рядка
        private void Change()
        {
            string nomAvt = textBoxDerNomAvt.Text;
            string markAvt = textBoxMarka.Text;
            int yearVipusk;
            int probig;
            string activityAvt = comboBoxActivityAvt.SelectedItem?.ToString();


            if (!string.IsNullOrEmpty(activityAvt) && markAvt.All(char.IsLetter) && int.TryParse(textBoxYearVipusk.Text, out yearVipusk) && int.TryParse(textBoxProbig.Text, out probig))
            {

                if (dataGridViewAdminAvt.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                    // Отримуємо значення ключів для зміни рядка
                    string nomAvtToUpdate = Convert.ToString(dataGridViewAdminAvt.SelectedRows[0].Cells["Держ_номер_А"].Value);

                    string markAvtToUpdate = Convert.ToString(dataGridViewAdminAvt.SelectedRows[0].Cells["Марка_А"].Value); 
                    int yearVipuskToUpdate = Convert.ToInt32(dataGridViewAdminAvt.SelectedRows[0].Cells["Рік_випуск"].Value); 
                    int probigToUpdate = Convert.ToInt32(dataGridViewAdminAvt.SelectedRows[0].Cells["Пробіг"].Value); 
                    string activityAvtToUpdate = Convert.ToString(dataGridViewAdminAvt.SelectedRows[0].Cells["АктивністьАвт"].Value); 
                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        // Змінюємо дані рядка
                        string newnomAvt = Convert.ToString(textBoxDerNomAvt.Text);
                        string newmarkAvt = Convert.ToString(textBoxMarka.Text);
                        int newyearVipusk= Convert.ToInt32(textBoxYearVipusk.Text);
                        int newprobig= Convert.ToInt32(textBoxProbig.Text);
                        string newactivityAvt = Convert.ToString(comboBoxActivityAvt.SelectedItem?.ToString());



                        // Перевірка, чи дані змінилися
                        if (newnomAvt == nomAvtToUpdate && newmarkAvt == markAvtToUpdate && newyearVipusk == yearVipuskToUpdate && newprobig == probigToUpdate && newactivityAvt == activityAvtToUpdate)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        // Валідація даних
                        if (newnomAvt.Length > 8 || newmarkAvt.Length > 20)
                        {
                            MessageBox.Show("Недопустима кількість символів. (Держ. ном. авт -максимум 8, Марка авт. -максимум 20).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                        if (newprobig < 0)
                        {
                            MessageBox.Show("Пробіг має бути більше за 0 або 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                        if (newyearVipusk < 2000 || newyearVipusk > 2023)
                        {
                            MessageBox.Show("Рік випуску має бути в діапазоні від 2000 до 2023 включно.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        // Перевірка на дублікат
                        if (RowExists(newnomAvt) && (newnomAvt != nomAvtToUpdate))
                        {
                            MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }




                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Автобуси SET Держ_номер_А = @NewnomAvt, Марка_А = @NewmarkAvt, Рік_випуск = @NewyearVipusk, Пробіг = @Newprobig, АктивністьАвт = @NewactivityAvt " +
                                             "WHERE Держ_номер_А = @NomAvtToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomAvtToUpdate", nomAvtToUpdate);
                            command.Parameters.AddWithValue("@NewnomAvt", newnomAvt);
                            command.Parameters.AddWithValue("@NewmarkAvt", newmarkAvt);
                            command.Parameters.AddWithValue("@NewyearVipusk", newyearVipusk);
                            command.Parameters.AddWithValue("@Newprobig", newprobig);
                            command.Parameters.AddWithValue("@NewactivityAvt", newactivityAvt);


                            command.ExecuteNonQuery();


                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewAdminAvt);
                        }
                    }
                    dataBase.closeConnection();
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxDerNomAvt.Text = "";
            textBoxMarka.Text = "";
            textBoxYearVipusk.Text = "";
            textBoxProbig.Text = "";
            comboBoxActivityAvt.Text = "";
        }

        private void FormAdminAvt_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminAvt);
        }

        private void dataGridViewAdminAvt_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminAvt.Rows[selectedRow];

                textBoxDerNomAvt.Text = row.Cells[0].Value.ToString();
                textBoxMarka.Text = row.Cells[1].Value.ToString();
                textBoxYearVipusk.Text = row.Cells[2].Value.ToString();
                textBoxProbig.Text = row.Cells[3].Value.ToString();
                comboBoxActivityAvt.Text = row.Cells[4].Value.ToString();

            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminAvt);
        }

        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAdminAvt);
        }
    }
}
