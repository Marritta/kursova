﻿using kursova_1.Forms.AdminForms.Analytics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdmin : Form
    {
        public FormAdmin()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void buttonMarsh_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminMarsh formAdminMarsh = new FormAdminMarsh();

            // Відображення форми Welcome
            formAdminMarsh.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonZupink_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminZupink formAdminZupink = new FormAdminZupink();

            // Відображення форми Welcome
            formAdminZupink.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonZupinkNaMarsh_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminMarshZupinki formAdminMarshZupinki = new FormAdminMarshZupinki();

            // Відображення форми Welcome
            formAdminMarshZupinki.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonRob_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminRob formAdminRob = new FormAdminRob();

            // Відображення форми Welcome
            formAdminRob.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonOklad_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminOklad formAdminOklad = new FormAdminOklad();

            // Відображення форми Welcome
            formAdminOklad.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            Welcome welcomeForm = new Welcome();

            // Відображення форми Welcome
            welcomeForm.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonAvt_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAdminAvt formAdminAvt = new FormAdminAvt();

            // Відображення форми Welcome
            formAdminAvt.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonAnaliz_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
           FormAnalytics formAnalytics = new FormAnalytics();

            // Відображення форми Welcome
            formAnalytics.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonZvilnenyaRob_Click(object sender, EventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormZvilnenyaRob formZvilnenyaRob = new FormZvilnenyaRob();

            // Відображення форми Welcome
            formZvilnenyaRob.Show();

            // Закриття поточної форми
            this.Close();
        }
    }
}
