﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace kursova_1.Forms.AdminForms.Analytics
{
    public partial class FormAnalyticsZminVod : Form
    {
        DataBase dataBase = new DataBase();
        public FormAnalyticsZminVod()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAnalytics formAnalytics = new FormAnalytics();

            // Відображення форми Welcome
            formAnalytics.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonResult_Click(object sender, EventArgs e)
        {

            dataBase.openConnection();

            // SQL-запрос для подсчета количества рейсов для каждого автобуса
            string query = "SELECT Ном_Робіт_Водій, count(*) AS TotalZmin FROM Зміна GROUP BY Ном_Робіт_Водій";

            using (SqlCommand command = new SqlCommand(query, dataBase.GetConnection()))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Очистка данных в Chart перед обновлением
                    chartZminVod.Series.Clear();

                    // Создание нового сериеса
                    Series series = new Series("Кількість змін");
                    series.ChartType = SeriesChartType.Bar;

                    // Установка вертикальной ориентации столбцов
                    series["PixelPointWidth"] = "20"; // Установите необходимую ширину столбцов
                    series["PointWidth"] = "0.6";

                    while (reader.Read())
                    {
                        // Добавление данных к сериесу
                        series.Points.AddXY(reader["Ном_Робіт_Водій"].ToString(), Convert.ToInt32(reader["TotalZmin"]));
                    }

                    // Добавление сериеса на Chart
                    chartZminVod.Series.Add(series);
                }
            }

            dataBase.closeConnection();
        }
    }
}
