﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace kursova_1.Forms.AdminForms.Analytics
{
    public partial class FormAnalyticsReysMarsh : Form
    {
        DataBase dataBase = new DataBase();
        public FormAnalyticsReysMarsh()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAnalytics formAnalytics = new FormAnalytics();

            // Відображення форми Welcome
            formAnalytics.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonResult_Click(object sender, EventArgs e)
        {

            dataBase.openConnection();

            // SQL-запрос для подсчета количества рейсов для каждого автобуса
            string query = "SELECT Номер_марш, SUM(Кільк_викон_рейсів) AS TotalReys FROM Зміна GROUP BY Номер_марш";

            using (SqlCommand command = new SqlCommand(query, dataBase.GetConnection()))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Очистка данных в Chart перед обновлением
                    chartReysMarsh.Series.Clear();

                    // Создание нового сериеса
                    Series series = new Series("Кількість рейсів");
                    series.ChartType = SeriesChartType.Bar;

                    // Установка вертикальной ориентации столбцов
                    series["PixelPointWidth"] = "20"; // Установите необходимую ширину столбцов
                    series["PointWidth"] = "0.6";

                    while (reader.Read())
                    {
                        // Добавление данных к сериесу
                        series.Points.AddXY(reader["Номер_марш"].ToString(), Convert.ToInt32(reader["TotalReys"]));
                    }

                    // Добавление сериеса на Chart
                    chartReysMarsh.Series.Add(series);
                }
            }

            dataBase.closeConnection();
        }
    }
}
