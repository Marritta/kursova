﻿namespace kursova_1.Forms.AdminForms.Analytics
{
    partial class FormMoneyAvt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.buttonResult = new System.Windows.Forms.Button();
            this.chartZminKond = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBoxDateZmin = new System.Windows.Forms.ComboBox();
            this.comboBoxZmina = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartZminKond)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBoxZmina);
            this.panel1.Controls.Add(this.comboBoxDateZmin);
            this.panel1.Controls.Add(this.linkLabelBack);
            this.panel1.Controls.Add(this.buttonResult);
            this.panel1.Controls.Add(this.chartZminKond);
            this.panel1.Location = new System.Drawing.Point(7, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(787, 545);
            this.panel1.TabIndex = 3;
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(732, 20);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 3;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // buttonResult
            // 
            this.buttonResult.Location = new System.Drawing.Point(589, 247);
            this.buttonResult.Name = "buttonResult";
            this.buttonResult.Size = new System.Drawing.Size(155, 53);
            this.buttonResult.TabIndex = 2;
            this.buttonResult.Text = "Отримати результат";
            this.buttonResult.UseVisualStyleBackColor = true;
            this.buttonResult.Click += new System.EventHandler(this.buttonResult_Click);
            // 
            // chartZminKond
            // 
            chartArea3.Name = "ChartArea1";
            this.chartZminKond.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chartZminKond.Legends.Add(legend3);
            this.chartZminKond.Location = new System.Drawing.Point(7, 20);
            this.chartZminKond.Name = "chartZminKond";
            this.chartZminKond.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chartZminKond.Series.Add(series3);
            this.chartZminKond.Size = new System.Drawing.Size(521, 507);
            this.chartZminKond.TabIndex = 1;
            this.chartZminKond.Text = "chart1";
            // 
            // comboBoxDateZmin
            // 
            this.comboBoxDateZmin.FormattingEnabled = true;
            this.comboBoxDateZmin.Location = new System.Drawing.Point(589, 83);
            this.comboBoxDateZmin.Name = "comboBoxDateZmin";
            this.comboBoxDateZmin.Size = new System.Drawing.Size(155, 21);
            this.comboBoxDateZmin.TabIndex = 4;
            // 
            // comboBoxZmina
            // 
            this.comboBoxZmina.FormattingEnabled = true;
            this.comboBoxZmina.Location = new System.Drawing.Point(589, 154);
            this.comboBoxZmina.Name = "comboBoxZmina";
            this.comboBoxZmina.Size = new System.Drawing.Size(155, 21);
            this.comboBoxZmina.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(586, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Дата зміни";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(586, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Зміна";
            // 
            // FormMoneyAvt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel1);
            this.Name = "FormMoneyAvt";
            this.Text = "FormMoneyAvt";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartZminKond)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxZmina;
        private System.Windows.Forms.ComboBox comboBoxDateZmin;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.Button buttonResult;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartZminKond;
    }
}