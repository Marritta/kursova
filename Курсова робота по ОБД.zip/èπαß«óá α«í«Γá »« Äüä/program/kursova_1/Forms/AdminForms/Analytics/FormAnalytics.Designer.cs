﻿namespace kursova_1.Forms.AdminForms.Analytics
{
    partial class FormAnalytics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.labelHeader = new System.Windows.Forms.Label();
            this.buttonMarsh = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonAnalytics2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonAnalytics3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.linkLabelBack);
            this.panel1.Controls.Add(this.labelHeader);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(12, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(780, 50);
            this.panel1.TabIndex = 2;
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(723, 17);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 1;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // labelHeader
            // 
            this.labelHeader.AutoSize = true;
            this.labelHeader.Location = new System.Drawing.Point(18, 17);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new System.Drawing.Size(166, 13);
            this.labelHeader.TabIndex = 0;
            this.labelHeader.Text = "Аналіз діяльності підприємства";
            // 
            // buttonMarsh
            // 
            this.buttonMarsh.Location = new System.Drawing.Point(374, 101);
            this.buttonMarsh.Name = "buttonMarsh";
            this.buttonMarsh.Size = new System.Drawing.Size(138, 26);
            this.buttonMarsh.TabIndex = 5;
            this.buttonMarsh.Text = "Подивитися";
            this.buttonMarsh.UseVisualStyleBackColor = true;
            this.buttonMarsh.Click += new System.EventHandler(this.buttonMarsh_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Кількість рейсів виконаних кожним автобусом";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(256, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Кількість рейсів виконаних на кожному маршруті";
            // 
            // buttonAnalytics2
            // 
            this.buttonAnalytics2.Location = new System.Drawing.Point(374, 145);
            this.buttonAnalytics2.Name = "buttonAnalytics2";
            this.buttonAnalytics2.Size = new System.Drawing.Size(138, 26);
            this.buttonAnalytics2.TabIndex = 8;
            this.buttonAnalytics2.Text = "Подивитися";
            this.buttonAnalytics2.UseVisualStyleBackColor = true;
            this.buttonAnalytics2.Click += new System.EventHandler(this.buttonAnalytics2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(122, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(243, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Кількість змін відпрацьованих кожним водієм ";
            // 
            // buttonAnalytics3
            // 
            this.buttonAnalytics3.Location = new System.Drawing.Point(374, 191);
            this.buttonAnalytics3.Name = "buttonAnalytics3";
            this.buttonAnalytics3.Size = new System.Drawing.Size(138, 26);
            this.buttonAnalytics3.TabIndex = 10;
            this.buttonAnalytics3.Text = "Подивитися";
            this.buttonAnalytics3.UseVisualStyleBackColor = true;
            this.buttonAnalytics3.Click += new System.EventHandler(this.buttonAnalytics3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(93, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(272, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Кількість змін відпрацьованих кожним кондуктором";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(374, 234);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 26);
            this.button1.TabIndex = 12;
            this.button1.Text = "Подивитися";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(147, 284);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(218, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Виручка автобуса у введену дату та зміну";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(374, 277);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(138, 26);
            this.button2.TabIndex = 14;
            this.button2.Text = "Подивитися";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(130, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(235, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Виручка маршруту у введену дату або місяць";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(374, 320);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 26);
            this.button3.TabIndex = 16;
            this.button3.Text = "Подивитися";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // FormAnalytics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonAnalytics3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonAnalytics2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonMarsh);
            this.Controls.Add(this.panel1);
            this.Name = "FormAnalytics";
            this.Text = "FormAnalytics";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.Label labelHeader;
        private System.Windows.Forms.Button buttonMarsh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonAnalytics2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAnalytics3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
    }
}