﻿namespace kursova_1.Forms.AdminForms.Analytics
{
    partial class FormAnalyticsReysAvt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chartReysAvt = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonResult = new System.Windows.Forms.Button();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.chartReysAvt)).BeginInit();
            this.SuspendLayout();
            // 
            // chartReysAvt
            // 
            chartArea2.Name = "ChartArea1";
            this.chartReysAvt.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartReysAvt.Legends.Add(legend2);
            this.chartReysAvt.Location = new System.Drawing.Point(21, 18);
            this.chartReysAvt.Name = "chartReysAvt";
            this.chartReysAvt.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartReysAvt.Series.Add(series2);
            this.chartReysAvt.Size = new System.Drawing.Size(521, 507);
            this.chartReysAvt.TabIndex = 0;
            this.chartReysAvt.Text = "chart1";
            // 
            // buttonResult
            // 
            this.buttonResult.Location = new System.Drawing.Point(599, 254);
            this.buttonResult.Name = "buttonResult";
            this.buttonResult.Size = new System.Drawing.Size(155, 53);
            this.buttonResult.TabIndex = 1;
            this.buttonResult.Text = "Отримати результат";
            this.buttonResult.UseVisualStyleBackColor = true;
            this.buttonResult.Click += new System.EventHandler(this.buttonResult_Click);
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(738, 18);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 2;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // FormAnalyticsReysAvt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.buttonResult);
            this.Controls.Add(this.chartReysAvt);
            this.Name = "FormAnalyticsReysAvt";
            this.Text = "FormAnalyticsReysAvt";
            ((System.ComponentModel.ISupportInitialize)(this.chartReysAvt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chartReysAvt;
        private System.Windows.Forms.Button buttonResult;
        private System.Windows.Forms.LinkLabel linkLabelBack;
    }
}