﻿namespace kursova_1.Forms.AdminForms.Analytics
{
    partial class FormMoneyMarsh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxDateZmin = new System.Windows.Forms.ComboBox();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.buttonResult = new System.Windows.Forms.Button();
            this.chartMoneyMarsh = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonResult2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartMoneyMarsh)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buttonResult2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBoxDateZmin);
            this.panel1.Controls.Add(this.linkLabelBack);
            this.panel1.Controls.Add(this.buttonResult);
            this.panel1.Controls.Add(this.chartMoneyMarsh);
            this.panel1.Location = new System.Drawing.Point(7, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(787, 545);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(586, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Дата зміни";
            // 
            // comboBoxDateZmin
            // 
            this.comboBoxDateZmin.FormattingEnabled = true;
            this.comboBoxDateZmin.Location = new System.Drawing.Point(589, 83);
            this.comboBoxDateZmin.Name = "comboBoxDateZmin";
            this.comboBoxDateZmin.Size = new System.Drawing.Size(155, 21);
            this.comboBoxDateZmin.TabIndex = 4;
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(732, 20);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 3;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // buttonResult
            // 
            this.buttonResult.Location = new System.Drawing.Point(589, 178);
            this.buttonResult.Name = "buttonResult";
            this.buttonResult.Size = new System.Drawing.Size(155, 53);
            this.buttonResult.TabIndex = 2;
            this.buttonResult.Text = "Отримати результат(за день)";
            this.buttonResult.UseVisualStyleBackColor = true;
            this.buttonResult.Click += new System.EventHandler(this.buttonResult_Click);
            // 
            // chartMoneyMarsh
            // 
            chartArea2.Name = "ChartArea1";
            this.chartMoneyMarsh.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartMoneyMarsh.Legends.Add(legend2);
            this.chartMoneyMarsh.Location = new System.Drawing.Point(7, 20);
            this.chartMoneyMarsh.Name = "chartMoneyMarsh";
            this.chartMoneyMarsh.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartMoneyMarsh.Series.Add(series2);
            this.chartMoneyMarsh.Size = new System.Drawing.Size(521, 507);
            this.chartMoneyMarsh.TabIndex = 1;
            this.chartMoneyMarsh.Text = "chart1";
            // 
            // buttonResult2
            // 
            this.buttonResult2.Location = new System.Drawing.Point(589, 264);
            this.buttonResult2.Name = "buttonResult2";
            this.buttonResult2.Size = new System.Drawing.Size(155, 53);
            this.buttonResult2.TabIndex = 7;
            this.buttonResult2.Text = "Отримати результат(за місяць)";
            this.buttonResult2.UseVisualStyleBackColor = true;
            this.buttonResult2.Click += new System.EventHandler(this.buttonResult2_Click);
            // 
            // FormMoneyMarsh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel1);
            this.Name = "FormMoneyMarsh";
            this.Text = "FormMoneyMarsh";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartMoneyMarsh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxDateZmin;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.Button buttonResult;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMoneyMarsh;
        private System.Windows.Forms.Button buttonResult2;
    }
}