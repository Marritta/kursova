﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace kursova_1.Forms.AdminForms.Analytics
{
    public partial class FormMoneyMarsh : Form
    {
        DataBase dataBase = new DataBase();
        public FormMoneyMarsh()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxDateZmin.DropDownStyle = ComboBoxStyle.DropDownList;
            LoadDaysToComboBox();
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAnalytics formAnalytics = new FormAnalytics();

            // Відображення форми Welcome
            formAnalytics.Show();

            // Закриття поточної форми
            this.Close();
        }
        private void LoadDaysToComboBox()
        {
            dataBase.openConnection();

            // SQL-запрос для загрузки уникальных дней из таблицы Зміна
            string query = "SELECT DISTINCT ДатаПлан FROM Зміна";

            using (SqlCommand command = new SqlCommand(query, dataBase.GetConnection()))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxDateZmin.Items.Add(reader.GetDateTime(0).ToShortDateString());
                    }
                }
            }

            dataBase.closeConnection();
        }

        private void buttonResult_Click(object sender, EventArgs e)
        {
            if (comboBoxDateZmin.SelectedItem == null )
            {
                MessageBox.Show("Оберіть дані для аналізу.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            dataBase.openConnection();

            DateTime selectedDay = Convert.ToDateTime(comboBoxDateZmin.Text);

            string dailyQuery = "SELECT з.Номер_марш, SUM(з.КількЛюдей * м.ЦінаПроїзд) AS DailyRevenue " +
                                "FROM Зміна з " +
                                "INNER JOIN Маршрути м ON з.Номер_марш = м.Номер_марш " +
                                "WHERE з.ДатаПлан = @SelectedDay " +
                                "GROUP BY з.Номер_марш";

            using (SqlCommand dailyCommand = new SqlCommand(dailyQuery, dataBase.GetConnection()))
            {
                dailyCommand.Parameters.AddWithValue("@SelectedDay", selectedDay);

                using (SqlDataReader reader = dailyCommand.ExecuteReader())
                {
                    chartMoneyMarsh.Series.Clear();
                    Series series = new Series("Выручка за день");
                    series.ChartType = SeriesChartType.Bar; // Изменил тип диаграммы
                    series["PointWidth"] = "0.6";
                    series["PointGap"] = "1";

                    chartMoneyMarsh.Series.Add(series);

                    while (reader.Read())
                    {
                        chartMoneyMarsh.Series[0].Points.AddXY(reader["Номер_марш"].ToString(), Convert.ToDouble(reader["DailyRevenue"]));
                    }
                }
            }

            dataBase.closeConnection();
        }

        private void buttonResult2_Click(object sender, EventArgs e)
        {
            if (comboBoxDateZmin.SelectedItem == null)
            {
                MessageBox.Show("Оберіть дані для аналізу.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            dataBase.openConnection();

            DateTime selectedDate = Convert.ToDateTime(comboBoxDateZmin.Text);

            string monthlyQuery = "SELECT з.Номер_марш, SUM(з.КількЛюдей * м.ЦінаПроїзд) AS MonthlyRevenue " +
                                  "FROM Зміна з " +
                                  "INNER JOIN Маршрути м ON з.Номер_марш = м.Номер_марш " +
                                  "WHERE MONTH(ДатаПлан) = MONTH(@SelectedDate) AND YEAR(ДатаПлан) = YEAR(@SelectedDate) " +
                                  "GROUP BY з.Номер_марш";

            using (SqlCommand monthlyCommand = new SqlCommand(monthlyQuery, dataBase.GetConnection()))
            {
                monthlyCommand.Parameters.AddWithValue("@SelectedDate", selectedDate);

                using (SqlDataReader reader = monthlyCommand.ExecuteReader())
                {
                    chartMoneyMarsh.Series.Clear();
                    Series series = new Series("Виручка за місяць");
                    series.ChartType = SeriesChartType.Bar; // Изменил тип диаграммы
                    series["PointWidth"] = "0.6";
                    series["PointGap"] = "1";

                    chartMoneyMarsh.Series.Add(series);

                    while (reader.Read())
                    {
                        chartMoneyMarsh.Series[0].Points.AddXY(reader["Номер_марш"].ToString(), Convert.ToDouble(reader["MonthlyRevenue"]));
                    }
                }
            }

            dataBase.closeConnection();
        }
    }
}
