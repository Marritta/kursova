﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace kursova_1.Forms.AdminForms.Analytics
{
    public partial class FormMoneyAvt : Form
    {
        DataBase dataBase = new DataBase();
        public FormMoneyAvt()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxDateZmin.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxZmina.DropDownStyle = ComboBoxStyle.DropDownList;
            // Загружаем даты в ComboBox
            LoadDatesToComboBox();

            // Загружаем смены в ComboBox
            LoadShiftsToComboBox();

        }
        private void LoadDatesToComboBox()
        {
            dataBase.openConnection();

            // SQL-запрос для загрузки уникальных дат из таблицы Зміна
            string query = "SELECT DISTINCT ДатаПлан FROM Зміна";

            using (SqlCommand command = new SqlCommand(query, dataBase.GetConnection()))
            {
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxDateZmin.Items.Add(reader.GetDateTime(0).ToShortDateString());
                    }
                }
            }

            dataBase.closeConnection();
        }

        private void LoadShiftsToComboBox()
        {
            // Загружаем смены в ComboBox
            for (int i = 1; i <= 2; i++) // предполагаем, что у вас всего 3 смены
            {
                comboBoxZmina.Items.Add(i);
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми Welcome
            FormAnalytics formAnalytics = new FormAnalytics();

            // Відображення форми Welcome
            formAnalytics.Show();

            // Закриття поточної форми
            this.Close();
        }

        private void buttonResult_Click(object sender, EventArgs e)
        {    // Проверка, были ли выбраны данные из комбобоксов
            if (comboBoxDateZmin.SelectedItem == null || comboBoxZmina.SelectedItem == null)
            {
                MessageBox.Show("Оберіть дані для аналізу.", "Попередження", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DateTime selectedDate = Convert.ToDateTime(comboBoxDateZmin.Text);
            int selectedShift = Convert.ToInt32(comboBoxZmina.Text);
            dataBase.openConnection();

            // SQL-запрос для подсчета выручки для каждого автобуса
            string query = $"SELECT Держ_номер_А, SUM(КількЛюдей * ЦінаПроїзд) AS TotalRevenue " +
                           $"FROM Зміна з " +
                           $"INNER JOIN Маршрути м ON з.Номер_марш = м.Номер_марш " +
                           $"WHERE ДатаПлан = @SelectedDate AND Номер_Зміни = @SelectedShift " +
                           $"GROUP BY Держ_номер_А";

            using (SqlCommand command = new SqlCommand(query, dataBase.GetConnection()))
            {
                // Добавляем параметры к запросу
                command.Parameters.AddWithValue("@SelectedDate", selectedDate);
                command.Parameters.AddWithValue("@SelectedShift", selectedShift);

                chartZminKond.Series.Clear();
                Series series = new Series("Виручка");
                series.ChartType = SeriesChartType.Bar;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Очистка данных в Chart перед обновлением
                    chartZminKond.Series.Add(series); // Добавляем серию в Chart

                    while (reader.Read())
                    {
                        // Добавление данных к сериесу
                        chartZminKond.Series[0].Points.AddXY(reader["Держ_номер_А"].ToString(), Convert.ToDouble(reader["TotalRevenue"]));
                    }
                }
            }

            dataBase.closeConnection();
        }
    }
    
}
