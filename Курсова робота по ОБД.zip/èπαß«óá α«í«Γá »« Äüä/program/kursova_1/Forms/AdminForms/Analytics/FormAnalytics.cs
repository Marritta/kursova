﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace kursova_1.Forms.AdminForms.Analytics
{
    public partial class FormAnalytics : Form
    {
        public FormAnalytics()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Переход на FormAdmin
            FormAdmin formAdmin = new FormAdmin();
            formAdmin.Show();
            this.Hide();
        }

        private void buttonMarsh_Click(object sender, EventArgs e)
        {
           FormAnalyticsReysAvt formAnalyticsReysAvt = new FormAnalyticsReysAvt();
            formAnalyticsReysAvt.Show();
            this.Hide();
        }

        private void buttonAnalytics2_Click(object sender, EventArgs e)
        {
            FormAnalyticsReysMarsh formAnalyticsReysMarsh = new FormAnalyticsReysMarsh();
            formAnalyticsReysMarsh.Show();
            this.Hide();
        }

        private void buttonAnalytics3_Click(object sender, EventArgs e)
        {
            FormAnalyticsZminVod formAnalyticsZminVod = new FormAnalyticsZminVod();
            formAnalyticsZminVod.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAnalyticsZminKond formAnalyticsZminKond = new FormAnalyticsZminKond();
            formAnalyticsZminKond.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormMoneyAvt formMoneyAvt = new FormMoneyAvt();
            formMoneyAvt.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormMoneyMarsh formMoneyMarsh = new FormMoneyMarsh();
            formMoneyMarsh.Show();
            this.Hide();
        }
    }
}
