﻿namespace kursova_1.Forms.AdminForms
{
    partial class FormAdminAvt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewAdminAvt = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBoxActivityAvt = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxProbig = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxMarka = new System.Windows.Forms.TextBox();
            this.textBoxDerNomAvt = new System.Windows.Forms.TextBox();
            this.textBoxYearVipusk = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonSaveNewRow = new System.Windows.Forms.Button();
            this.buttonUpdateZapis = new System.Windows.Forms.Button();
            this.buttonDeleteZapis = new System.Windows.Forms.Button();
            this.buttonRefreshDani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminAvt)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 59);
            this.panel1.TabIndex = 3;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(529, 18);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(71, 20);
            this.buttonRefresh.TabIndex = 4;
            this.buttonRefresh.Text = "Оновити";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(628, 18);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(129, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Автобуси";
            // 
            // dataGridViewAdminAvt
            // 
            this.dataGridViewAdminAvt.AllowUserToAddRows = false;
            this.dataGridViewAdminAvt.AllowUserToDeleteRows = false;
            this.dataGridViewAdminAvt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdminAvt.Location = new System.Drawing.Point(12, 108);
            this.dataGridViewAdminAvt.Name = "dataGridViewAdminAvt";
            this.dataGridViewAdminAvt.ReadOnly = true;
            this.dataGridViewAdminAvt.Size = new System.Drawing.Size(776, 225);
            this.dataGridViewAdminAvt.TabIndex = 6;
            this.dataGridViewAdminAvt.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAdminAvt_CellClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.comboBoxActivityAvt);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBoxProbig);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.textBoxMarka);
            this.panel2.Controls.Add(this.textBoxDerNomAvt);
            this.panel2.Controls.Add(this.textBoxYearVipusk);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 350);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(418, 189);
            this.panel2.TabIndex = 7;
            // 
            // comboBoxActivityAvt
            // 
            this.comboBoxActivityAvt.FormattingEnabled = true;
            this.comboBoxActivityAvt.Location = new System.Drawing.Point(238, 124);
            this.comboBoxActivityAvt.Name = "comboBoxActivityAvt";
            this.comboBoxActivityAvt.Size = new System.Drawing.Size(156, 21);
            this.comboBoxActivityAvt.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(121, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Активність автобуса";
            // 
            // textBoxProbig
            // 
            this.textBoxProbig.Location = new System.Drawing.Point(238, 96);
            this.textBoxProbig.Name = "textBoxProbig";
            this.textBoxProbig.Size = new System.Drawing.Size(156, 20);
            this.textBoxProbig.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(75, 98);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Пробіг(на момент придбання)";
            // 
            // textBoxMarka
            // 
            this.textBoxMarka.Location = new System.Drawing.Point(238, 45);
            this.textBoxMarka.Name = "textBoxMarka";
            this.textBoxMarka.Size = new System.Drawing.Size(156, 20);
            this.textBoxMarka.TabIndex = 7;
            // 
            // textBoxDerNomAvt
            // 
            this.textBoxDerNomAvt.Location = new System.Drawing.Point(238, 19);
            this.textBoxDerNomAvt.Name = "textBoxDerNomAvt";
            this.textBoxDerNomAvt.Size = new System.Drawing.Size(156, 20);
            this.textBoxDerNomAvt.TabIndex = 6;
            // 
            // textBoxYearVipusk
            // 
            this.textBoxYearVipusk.Location = new System.Drawing.Point(238, 71);
            this.textBoxYearVipusk.Name = "textBoxYearVipusk";
            this.textBoxYearVipusk.Size = new System.Drawing.Size(156, 20);
            this.textBoxYearVipusk.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(167, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Рік випуску";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(189, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Марка ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(81, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Державний номер Автобуса";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дані:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.buttonSaveNewRow);
            this.panel3.Controls.Add(this.buttonUpdateZapis);
            this.panel3.Controls.Add(this.buttonDeleteZapis);
            this.panel3.Controls.Add(this.buttonRefreshDani);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(541, 350);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 189);
            this.panel3.TabIndex = 14;
            // 
            // buttonSaveNewRow
            // 
            this.buttonSaveNewRow.Location = new System.Drawing.Point(24, 64);
            this.buttonSaveNewRow.Name = "buttonSaveNewRow";
            this.buttonSaveNewRow.Size = new System.Drawing.Size(131, 23);
            this.buttonSaveNewRow.TabIndex = 4;
            this.buttonSaveNewRow.Text = "Зберегти новий запис";
            this.buttonSaveNewRow.UseVisualStyleBackColor = true;
            this.buttonSaveNewRow.Click += new System.EventHandler(this.buttonSaveNewRow_Click);
            // 
            // buttonUpdateZapis
            // 
            this.buttonUpdateZapis.Location = new System.Drawing.Point(24, 122);
            this.buttonUpdateZapis.Name = "buttonUpdateZapis";
            this.buttonUpdateZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonUpdateZapis.TabIndex = 3;
            this.buttonUpdateZapis.Text = "Змінити";
            this.buttonUpdateZapis.UseVisualStyleBackColor = true;
            this.buttonUpdateZapis.Click += new System.EventHandler(this.buttonUpdateZapis_Click);
            // 
            // buttonDeleteZapis
            // 
            this.buttonDeleteZapis.Location = new System.Drawing.Point(24, 93);
            this.buttonDeleteZapis.Name = "buttonDeleteZapis";
            this.buttonDeleteZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonDeleteZapis.TabIndex = 2;
            this.buttonDeleteZapis.Text = "Видалити";
            this.buttonDeleteZapis.UseVisualStyleBackColor = true;
            this.buttonDeleteZapis.Click += new System.EventHandler(this.buttonDeleteZapis_Click);
            // 
            // buttonRefreshDani
            // 
            this.buttonRefreshDani.Location = new System.Drawing.Point(24, 35);
            this.buttonRefreshDani.Name = "buttonRefreshDani";
            this.buttonRefreshDani.Size = new System.Drawing.Size(131, 23);
            this.buttonRefreshDani.TabIndex = 1;
            this.buttonRefreshDani.Text = "Очистити дані";
            this.buttonRefreshDani.UseVisualStyleBackColor = true;
            this.buttonRefreshDani.Click += new System.EventHandler(this.buttonRefreshDani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Управління записами";
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(749, 27);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 9;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // FormAdminAvt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridViewAdminAvt);
            this.Controls.Add(this.panel1);
            this.Name = "FormAdminAvt";
            this.Text = "FormAdminAvt";
            this.Load += new System.EventHandler(this.FormAdminAvt_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminAvt)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridViewAdminAvt;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxProbig;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxMarka;
        private System.Windows.Forms.TextBox textBoxDerNomAvt;
        private System.Windows.Forms.TextBox textBoxYearVipusk;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonSaveNewRow;
        private System.Windows.Forms.Button buttonUpdateZapis;
        private System.Windows.Forms.Button buttonDeleteZapis;
        private System.Windows.Forms.Button buttonRefreshDani;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.ComboBox comboBoxActivityAvt;
    }
}