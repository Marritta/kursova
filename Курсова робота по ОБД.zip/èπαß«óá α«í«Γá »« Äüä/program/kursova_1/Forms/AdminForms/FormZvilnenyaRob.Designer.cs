﻿namespace kursova_1.Forms.AdminForms
{
    partial class FormZvilnenyaRob
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabelBack = new System.Windows.Forms.LinkLabel();
            this.dataGridViewAdminRob = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBoxDateZvilZRob = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNomRob = new System.Windows.Forms.TextBox();
            this.textBoxPibRob = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonUpdateZapis = new System.Windows.Forms.Button();
            this.buttonRefreshDani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminRob)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.buttonRefresh);
            this.panel1.Controls.Add(this.textBoxSearch);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 59);
            this.panel1.TabIndex = 3;
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(531, 18);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(71, 20);
            this.buttonRefresh.TabIndex = 3;
            this.buttonRefresh.Text = "Оновити";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(628, 18);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(129, 20);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Робітники (Звільнення)";
            // 
            // linkLabelBack
            // 
            this.linkLabelBack.AutoSize = true;
            this.linkLabelBack.Location = new System.Drawing.Point(749, 22);
            this.linkLabelBack.Name = "linkLabelBack";
            this.linkLabelBack.Size = new System.Drawing.Size(39, 13);
            this.linkLabelBack.TabIndex = 4;
            this.linkLabelBack.TabStop = true;
            this.linkLabelBack.Text = "Назад";
            this.linkLabelBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelBack_LinkClicked);
            // 
            // dataGridViewAdminRob
            // 
            this.dataGridViewAdminRob.AllowUserToAddRows = false;
            this.dataGridViewAdminRob.AllowUserToDeleteRows = false;
            this.dataGridViewAdminRob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdminRob.Location = new System.Drawing.Point(12, 103);
            this.dataGridViewAdminRob.Name = "dataGridViewAdminRob";
            this.dataGridViewAdminRob.Size = new System.Drawing.Size(776, 245);
            this.dataGridViewAdminRob.TabIndex = 5;
            this.dataGridViewAdminRob.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAdminRob_CellClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.textBoxDateZvilZRob);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBoxNomRob);
            this.panel2.Controls.Add(this.textBoxPibRob);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 360);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(556, 189);
            this.panel2.TabIndex = 6;
            // 
            // textBoxDateZvilZRob
            // 
            this.textBoxDateZvilZRob.Location = new System.Drawing.Point(259, 117);
            this.textBoxDateZvilZRob.Name = "textBoxDateZvilZRob";
            this.textBoxDateZvilZRob.Size = new System.Drawing.Size(156, 20);
            this.textBoxDateZvilZRob.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(150, 120);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 26);
            this.label12.TabIndex = 26;
            this.label12.Text = "Дата звільнення\r\nз роботи\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(149, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Номер робітника";
            // 
            // textBoxNomRob
            // 
            this.textBoxNomRob.Location = new System.Drawing.Point(259, 33);
            this.textBoxNomRob.Name = "textBoxNomRob";
            this.textBoxNomRob.Size = new System.Drawing.Size(155, 20);
            this.textBoxNomRob.TabIndex = 24;
            // 
            // textBoxPibRob
            // 
            this.textBoxPibRob.Location = new System.Drawing.Point(259, 76);
            this.textBoxPibRob.Name = "textBoxPibRob";
            this.textBoxPibRob.Size = new System.Drawing.Size(156, 20);
            this.textBoxPibRob.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(165, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ПІБ робітника";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дані:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.buttonUpdateZapis);
            this.panel3.Controls.Add(this.buttonRefreshDani);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(610, 372);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 169);
            this.panel3.TabIndex = 28;
            // 
            // buttonUpdateZapis
            // 
            this.buttonUpdateZapis.Location = new System.Drawing.Point(24, 82);
            this.buttonUpdateZapis.Name = "buttonUpdateZapis";
            this.buttonUpdateZapis.Size = new System.Drawing.Size(131, 23);
            this.buttonUpdateZapis.TabIndex = 3;
            this.buttonUpdateZapis.Text = "Змінити";
            this.buttonUpdateZapis.UseVisualStyleBackColor = true;
            this.buttonUpdateZapis.Click += new System.EventHandler(this.buttonUpdateZapis_Click);
            // 
            // buttonRefreshDani
            // 
            this.buttonRefreshDani.Location = new System.Drawing.Point(24, 35);
            this.buttonRefreshDani.Name = "buttonRefreshDani";
            this.buttonRefreshDani.Size = new System.Drawing.Size(131, 23);
            this.buttonRefreshDani.TabIndex = 1;
            this.buttonRefreshDani.Text = "Очистити дані";
            this.buttonRefreshDani.UseVisualStyleBackColor = true;
            this.buttonRefreshDani.Click += new System.EventHandler(this.buttonRefreshDani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Управління записами";
            // 
            // FormZvilnenyaRob
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridViewAdminRob);
            this.Controls.Add(this.linkLabelBack);
            this.Controls.Add(this.panel1);
            this.Name = "FormZvilnenyaRob";
            this.Text = "FormZvilnenyaRob";
            this.Load += new System.EventHandler(this.FormZvilnenyaRob_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdminRob)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabelBack;
        private System.Windows.Forms.DataGridView dataGridViewAdminRob;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBoxDateZvilZRob;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNomRob;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPibRob;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonUpdateZapis;
        private System.Windows.Forms.Button buttonRefreshDani;
        private System.Windows.Forms.Label label6;
    }
}