﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdminZupink : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormAdminZupink()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewAdminZupinki.Columns.Add("Назва_Зуп", "Назва зупинки");
        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetString(0));
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Зупинки";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            string nazvZup = textBoxNazvaZupinki.Text;

            if (RowExists(nazvZup))
            {
                MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataBase.closeConnection();
                return;
            }


            if (nazvZup.Length > 60)
            {
                MessageBox.Show("Недопустима кількість символів (максимум 60).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataBase.closeConnection();
                return;
            }



            var addQuery = $"insert into Зупинки(Назва_Зуп) values (@NazvZup)";

            using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NazvZup", nazvZup);

                command.ExecuteNonQuery();
            }

            MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshDataGrid(dataGridViewAdminZupinki);


            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(string nazvZup)
        {
            var checkQuery = $"select count(*) from Зупинки where Назва_Зуп = @NazvZup";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NazvZup", nazvZup);

                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Зупинки where convert(nvarchar(max), Назва_Зуп) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewAdminZupinki.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                string nazvZup = Convert.ToString(dataGridViewAdminZupinki.SelectedRows[0].Cells["Назва_Зуп"].Value);
               

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE from Зупинки where Назва_Зуп = @NazvZup";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@NazvZup", nazvZup);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewAdminZupinki);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //метод изменения рядка
        private void Change()
        {
            // Отримуємо значення з поля textBoxNazvaZupinki
            string newnazvZup = textBoxNazvaZupinki.Text;

            if (dataGridViewAdminZupinki.SelectedRows.Count > 0)
            {   
                // Відкриваємо підключення
                dataBase.openConnection();
                // Отримуємо значення ключів для зміни рядка
                string nazvZupToUpdate = Convert.ToString(dataGridViewAdminZupinki.SelectedRows[0].Cells["Назва_Зуп"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Перевірка, чи дані змінилися
                    if (newnazvZup == nazvZupToUpdate)
                    {
                        MessageBox.Show("Дані не було змінено, бо не було введено нової інформації.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    // Валідація даних
                    if (newnazvZup.Length > 60)
                    {
                        MessageBox.Show("Недопустима кількість символів (максимум 60).", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Перевірка на дублікат
                    if (RowExists(newnazvZup) && (newnazvZup != nazvZupToUpdate))
                    {
                        MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Виконуємо запит для зміни рядка
                    string updateQuery = "UPDATE Зупинки SET Назва_Зуп = @NewnazvZup " +
                                         "WHERE Назва_Зуп = @NazvZupToUpdate";

                    using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів та нових значень
                        command.Parameters.AddWithValue("@NazvZupToUpdate", nazvZupToUpdate);
                        command.Parameters.AddWithValue("@NewnazvZup", newnazvZup);



                        // Виконуємо запит
                        command.ExecuteNonQuery();


                        MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після зміни
                        RefreshDataGrid(dataGridViewAdminZupinki);
                    }
                }

                // Закриваємо підключення
                dataBase.closeConnection();
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNazvaZupinki.Text = "";
        }

        private void FormAdminZupink_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminZupinki);
        }

        private void dataGridViewAdminZupinki_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminZupinki.Rows[selectedRow];

                textBoxNazvaZupinki.Text = row.Cells[0].Value.ToString();

            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminZupinki);
        }

        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAdminZupinki);
        }
    }
}
