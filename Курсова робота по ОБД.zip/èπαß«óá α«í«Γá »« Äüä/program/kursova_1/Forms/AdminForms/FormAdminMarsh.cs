﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormAdminMarsh : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormAdminMarsh()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            comboBoxActivityMarsh.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActivityMarsh.Items.AddRange(new object[] { "True", "False" });
        }
        //метод створення атрибутов
        private void CreateColumns()
        {
            dataGridViewAdminMarsh.Columns.Add("Номер_марш", "Номер маршрута");
            dataGridViewAdminMarsh.Columns.Add("Протяж_марш", "Протяжність маршрута");
            dataGridViewAdminMarsh.Columns.Add("Сер_час_рейсу", "Середній час рейсу");
            dataGridViewAdminMarsh.Columns.Add("ЦінаРейсуАвтопідпр", "Ціна рейсу для підприємства");
            dataGridViewAdminMarsh.Columns.Add("ЦінаПроїзд", "Ціна проїзду");
            dataGridViewAdminMarsh.Columns.Add("АктивністьМарш", "Активність маршрута");

        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(
                record.GetInt32(0),
                record.GetInt32(1),
                ((TimeSpan)record.GetValue(2)).ToString(@"hh\:mm\:ss"),
                record.GetValue(3),
                record.GetValue(4),
                record.GetValue(5)
            );
        }


        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Маршрути";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }

        //метод сохранение нового кортежа
        private void SaveNewRow()
        {
            dataBase.openConnection();

            int nomMarsh;
            int protMarsh;
            TimeSpan avgTimeReys;
            double priceReysdouble;
            double priceProisddouble;
            string activityMarsh = comboBoxActivityMarsh.SelectedItem?.ToString();


            if (int.TryParse(textBoxNomMarsh.Text, out nomMarsh) && int.TryParse(textBoxProtMarsh.Text, out protMarsh) && TimeSpan.TryParse(textBoxAvgTimeReys.Text, out avgTimeReys)
                && double.TryParse(textBoxPriceReysuPidpr.Text, out priceReysdouble) && double.TryParse(textBoxPriceProezd.Text, out priceProisddouble))
            {
                SqlMoney priceReys = new SqlMoney(priceReysdouble);
                SqlMoney priceProisd = new SqlMoney(priceProisddouble);

                if (RowExists(nomMarsh))
                {
                    MessageBox.Show("Такий запис вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                if (priceReys <= 0 || priceProisd < 0)
                {
                    MessageBox.Show("Ціна проїзду та ціна рейсу для підприємства мають бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (protMarsh <= 0)
                {
                    MessageBox.Show("Протяжність має бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }
                if (nomMarsh < 0)
                {
                    MessageBox.Show("Номер маршрута має бути більше за 0 або 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataBase.closeConnection();
                    return;
                }

                var addQuery = $"insert into Маршрути(Номер_марш,Протяж_марш,Сер_час_рейсу,ЦінаРейсуАвтопідпр,ЦінаПроїзд,АктивністьМарш) values (@NomMarsh,@ProtMarsh,@AvgTimeReys,@PriceReys,@PriceProisd,@ActivityMarsh)";

                using (var command = new SqlCommand(addQuery, dataBase.GetConnection()))
                {
                    command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                    command.Parameters.AddWithValue("@ProtMarsh", protMarsh);
                    command.Parameters.AddWithValue("@AvgTimeReys", avgTimeReys);
                    command.Parameters.AddWithValue("@PriceReys", priceReys);
                    command.Parameters.AddWithValue("@PriceProisd", priceProisd);
                    command.Parameters.AddWithValue("@ActivityMarsh", activityMarsh);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Новий запис створено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshDataGrid(dataGridViewAdminMarsh);
            }
            else
            {
                MessageBox.Show("Введено некоректні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            dataBase.closeConnection();

        }
        // метод проверки на существование записи с таким же первичным ключом
        private bool RowExists(int nomMarsh)
        {
            var checkQuery = $"select count(*) from Маршрути where Номер_марш = @NomMarsh";
            using (var command = new SqlCommand(checkQuery, dataBase.GetConnection()))
            {
                command.Parameters.AddWithValue("@NomMarsh", nomMarsh);
                var count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        //метод поиска 
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear(); 
            string searchString = $"select * from Маршрути where convert(nvarchar(max), Номер_марш) + convert(nvarchar(max), Протяж_марш) " +
                $"+ convert(nvarchar(max), Сер_час_рейсу) + convert(nvarchar(max), ЦінаРейсуАвтопідпр) + convert(nvarchar(max), ЦінаПроїзд) + convert(nvarchar(max), АктивністьМарш) like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        //метод удаления кортежа
        private void deleteRow()
        {
            if (dataGridViewAdminMarsh.SelectedRows.Count > 0)
            {
                // Отримуємо значення ключів для видалення рядка
                int nomMarsh = Convert.ToInt32(dataGridViewAdminMarsh.SelectedRows[0].Cells["Номер_марш"].Value);

                // Показуємо діалогове вікно підтвердження
                DialogResult result = MessageBox.Show("Буде видалено вибраний рядок. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Виконуємо запит для видалення рядка за значеннями ключів
                    string deleteQuery = "DELETE FROM Маршрути WHERE Номер_марш = @NomMarsh";

                    using (SqlCommand command = new SqlCommand(deleteQuery, dataBase.GetConnection()))
                    {
                        // Додаємо параметри для значень ключів
                        command.Parameters.AddWithValue("@NomMarsh", nomMarsh);

                        dataBase.openConnection();
                        command.ExecuteNonQuery();
                        dataBase.closeConnection();

                        MessageBox.Show("Рядок видалено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Оновлюємо вміст DataGridView після видалення
                        RefreshDataGrid(dataGridViewAdminMarsh);
                    }
                }
            }
            else
            {
                MessageBox.Show("Будь ласка, виберіть рядок для видалення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //метод изменения рядка
        private void Change()
        {
            int nomMarsh;
            int protMarsh;
            TimeSpan avgTimeReys;
            double priceReysdouble;
            double priceProisddouble;



            if (int.TryParse(textBoxNomMarsh.Text, out nomMarsh) && int.TryParse(textBoxProtMarsh.Text, out protMarsh) && TimeSpan.TryParse(textBoxAvgTimeReys.Text, out avgTimeReys)
                && double.TryParse(textBoxPriceReysuPidpr.Text, out priceReysdouble) && double.TryParse(textBoxPriceProezd.Text, out priceProisddouble))
            {

                if (dataGridViewAdminMarsh.SelectedRows.Count > 0)
                {
                    dataBase.openConnection();
                    // Отримуємо значення ключів для зміни рядка

                    int nomMarshToUpdate = Convert.ToInt32(dataGridViewAdminMarsh.SelectedRows[0].Cells["Номер_марш"].Value);

                    int protMarshToUpdate = Convert.ToInt32(dataGridViewAdminMarsh.SelectedRows[0].Cells["Протяж_марш"].Value);
                    string timeString = dataGridViewAdminMarsh.SelectedRows[0].Cells["Сер_час_рейсу"].Value.ToString();
                    TimeSpan avgTimeReysToUpdate = TimeSpan.Parse(timeString);
                    double priceReysdoubleToUpdate = Convert.ToDouble(dataGridViewAdminMarsh.SelectedRows[0].Cells["ЦінаРейсуАвтопідпр"].Value);
                    double priceProisddoubleToUpdate = Convert.ToDouble(dataGridViewAdminMarsh.SelectedRows[0].Cells["ЦінаПроїзд"].Value);
                    string activityAvtToUpdateToUpdate = Convert.ToString(dataGridViewAdminMarsh.SelectedRows[0].Cells["АктивністьМарш"].Value); 
                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        // Змінюємо дані рядка
                        int newnomMarsh = Convert.ToInt32(textBoxNomMarsh.Text);
                        int newprotMarsh = Convert.ToInt32(textBoxProtMarsh.Text);
                        string newtimeString = textBoxAvgTimeReys.Text;
                        TimeSpan newavgTimeReys = TimeSpan.Parse(newtimeString);
                        double newpriceReysdouble = Convert.ToDouble(textBoxPriceReysuPidpr.Text);
                        double newpriceProisddouble = Convert.ToDouble(textBoxPriceProezd.Text); 
                        string newactivityMarsh = Convert.ToString(comboBoxActivityMarsh.SelectedItem?.ToString());

                        SqlMoney newpriceReys = new SqlMoney(newpriceReysdouble);
                        SqlMoney newpriceProisd = new SqlMoney(newpriceProisddouble);

                        // Перевірка, чи дані змінилися
                        if (newnomMarsh == nomMarshToUpdate && newprotMarsh == protMarshToUpdate && newavgTimeReys == avgTimeReysToUpdate
                            && newpriceReysdouble == priceReysdoubleToUpdate && newpriceProisddouble == priceProisddoubleToUpdate && newactivityMarsh == activityAvtToUpdateToUpdate)
                        {
                            MessageBox.Show("Дані не було змінено, бо не було введено нової інформації .", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        // Валідація даних
                        if (newpriceReys <= 0 || newpriceProisd < 0)
                        {
                            MessageBox.Show("Ціна проїзду та ціна рейсу для підприємства мають бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                        if (newprotMarsh <= 0)
                        {
                            MessageBox.Show("Протяжність має бути більше за 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }
                        if (newnomMarsh < 0)
                        {
                            MessageBox.Show("Номер маршрута має бути більше за 0 або 0.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            dataBase.closeConnection();
                            return;
                        }

                        // Перевірка на дублікат
                        if (RowExists(newnomMarsh) && (newnomMarsh != nomMarshToUpdate))
                        {
                            MessageBox.Show("Неможливо змінити рядок. Такий рядок вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return; 
                        }




                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Маршрути SET Номер_марш = @NewnomMarsh, Протяж_марш = @NewprotMarsh, Сер_час_рейсу = @NewavgTimeReys," +
                                            " ЦінаРейсуАвтопідпр = @NewpriceReys, ЦінаПроїзд = @NewpriceProisd, АктивністьМарш = @NewactivityMarsh " +
                                             "WHERE Номер_марш = @NomMarshToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomMarshToUpdate", nomMarshToUpdate);
                            command.Parameters.AddWithValue("@NewnomMarsh", newnomMarsh);
                            command.Parameters.AddWithValue("@NewprotMarsh", newprotMarsh);
                            command.Parameters.AddWithValue("@NewavgTimeReys", newavgTimeReys);
                            command.Parameters.AddWithValue("@NewpriceReys", newpriceReys);
                            command.Parameters.AddWithValue("@NewpriceProisd", newpriceProisd);
                            command.Parameters.AddWithValue("@NewactivityMarsh", newactivityMarsh);


                            command.ExecuteNonQuery();


                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewAdminMarsh);
                        }
                    }
                    dataBase.closeConnection();
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNomMarsh.Text = "";
            textBoxProtMarsh.Text = "";
            textBoxAvgTimeReys.Text = "";
            textBoxPriceReysuPidpr.Text = "";
            textBoxPriceProezd.Text = "";
            comboBoxActivityMarsh.Text = "";
        }

        private void FormAdminMarsh_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminMarsh);
        }

        private void dataGridViewAdminMarsh_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminMarsh.Rows[selectedRow];

                textBoxNomMarsh.Text = row.Cells[0].Value.ToString();
                textBoxProtMarsh.Text = row.Cells[1].Value.ToString();
                textBoxAvgTimeReys.Text = row.Cells[2].Value.ToString();
                textBoxPriceReysuPidpr.Text = row.Cells[3].Value.ToString();
                textBoxPriceProezd.Text = row.Cells[4].Value.ToString();
                comboBoxActivityMarsh.Text = row.Cells[5].Value.ToString();

            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminMarsh);
        }

        private void buttonSaveNewRow_Click(object sender, EventArgs e)
        {
            SaveNewRow();
        }

        private void buttonDeleteZapis_Click(object sender, EventArgs e)
        {
            deleteRow();
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridViewAdminMarsh);
        }
    }
}
