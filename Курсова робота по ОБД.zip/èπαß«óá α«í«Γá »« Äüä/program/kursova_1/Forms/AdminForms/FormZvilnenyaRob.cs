﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace kursova_1.Forms.AdminForms
{
    public partial class FormZvilnenyaRob : Form
    {
        DataBase dataBase = new DataBase();
        int selectedRow;
        public FormZvilnenyaRob()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        //метод створення атрибутов
        private void CreateColumns()
        {

            dataGridViewAdminRob.Columns.Add("Ном_Робіт", "Номер робітника");
            dataGridViewAdminRob.Columns.Add("ПІБ_Роб", "ПІБ Робітника");
            dataGridViewAdminRob.Columns.Add("ДатаЗвільн", "Дата звільнення");

        }
        //метод чтение 1 кортежа
        private void ReadSingleRow(DataGridView dgw, IDataRecord record)
        {
            dgw.Rows.Add(record.GetInt32(0), record.GetString(1), record.IsDBNull(9) ? (DateTime?)null : record.GetDateTime(9));
        }
        private void Search(DataGridView dgw)
        {
            dgw.Rows.Clear();
            string searchString = $"select * from Робітник where " +
                        "CONVERT(nvarchar(max), Ном_Робіт) + " +
                        "CONVERT(nvarchar(max), ПІБ_Роб)" +
                        $" like '%{textBoxSearch.Text}%'";

            SqlCommand com = new SqlCommand(searchString, dataBase.GetConnection());
            dataBase.openConnection();
            SqlDataReader read = com.ExecuteReader();

            while (read.Read())
            {
                ReadSingleRow(dgw, read);
            }
            read.Close();
        }
        //метод обновление datagridview
        private void RefreshDataGrid(DataGridView dgw)
        {
            dgw.Rows.Clear();

            string queryString = $"select * from Робітник";
            SqlCommand command = new SqlCommand(queryString, dataBase.GetConnection());

            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgw, reader);
            }
            reader.Close();
        }
        //метод изменения рядка
        private void Change()
        {
            int nomRob;
            DateTime dataZviln;


            if (DateTime.TryParse(textBoxDateZvilZRob.Text, out dataZviln))
            {

                if (dataGridViewAdminRob.SelectedRows.Count > 0)
                {
                    // Отримуємо значення ключів для зміни рядка
                    int nomRobToUpdate = Convert.ToInt32(dataGridViewAdminRob.SelectedRows[0].Cells["Ном_Робіт"].Value);

                    //string activityVodToUpdateToUpdate = Convert.ToString(dataGridViewAdminRob.SelectedRows[0].Cells["АктивністьВодій"].Value);

                    // Показуємо діалогове вікно підтвердження
                    DialogResult result = MessageBox.Show("Рядок буде змінено. Ви впевнені?", "Увага!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        // Змінюємо дані рядка
                        DateTime newdataZviln = Convert.ToDateTime(textBoxDateZvilZRob.Text);




                        // Виконуємо запит для зміни рядка
                        string updateQuery = "UPDATE Робітник SET ДатаЗвільн = @NewdataZviln " +
                                             "WHERE Ном_Робіт = @NomRobToUpdate";

                        using (SqlCommand command = new SqlCommand(updateQuery, dataBase.GetConnection()))
                        {
                            // Додаємо параметри для значень ключів та нових значень
                            command.Parameters.AddWithValue("@NomRobToUpdate", nomRobToUpdate);
                            command.Parameters.AddWithValue("@NewdataZviln", newdataZviln);


                            dataBase.openConnection();
                            command.ExecuteNonQuery();
                            dataBase.closeConnection();

                            MessageBox.Show("Рядок змінено.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Оновлюємо вміст DataGridView після зміни
                            RefreshDataGrid(dataGridViewAdminRob);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Будь ласка, виберіть рядок для зміни.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Неправильний формат даних.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        private void linkLabelBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Створення нового екземпляру форми FormDisp
            FormAdmin formAdmin = new FormAdmin();

            // Виклик методу Show() для відображення нової форми
            formAdmin.Show();

            // Додатково, якщо вам не потрібно залишати поточну форму відкритою, ви можете закрити її
            this.Hide();
        }

        private void FormZvilnenyaRob_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridViewAdminRob);
        }

        private void buttonRefreshDani_Click(object sender, EventArgs e)
        {
            textBoxNomRob.Text = "";
            textBoxPibRob.Text = "";
            textBoxDateZvilZRob.Text = "";
        }

        private void dataGridViewAdminRob_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewAdminRob.Rows[selectedRow];
                textBoxNomRob.Text = row.Cells[0].Value.ToString();
                textBoxPibRob.Text = row.Cells[1].Value.ToString();
            }
        }

        private void textBoxSearch_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridViewAdminRob);
        }

        private void buttonUpdateZapis_Click(object sender, EventArgs e)
        {
            Change();
        }
    }
}
