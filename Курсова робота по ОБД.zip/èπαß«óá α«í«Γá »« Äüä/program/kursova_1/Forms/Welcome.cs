﻿using System;
using System.Windows.Forms;

namespace kursova_1.Forms
{
    public partial class Welcome : Form
    {
        DataBase dataBase = new DataBase();
        public Welcome()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void buttonDisp_Click(object sender, EventArgs e)
        {
            
            FormPassword formPassword = new FormPassword();

           
            formPassword.Show();

           
            this.Hide();
        }

        private void buttonAdmin_Click(object sender, EventArgs e)
        {
            
            FormPassword formPassword = new FormPassword();

            
            formPassword.Show();

           
            this.Hide();
        }

        private void buttonVodiy_Click(object sender, EventArgs e)
        {
            
            FormPassword formPassword = new FormPassword();

           
            formPassword.Show();

           
            this.Hide();
        }

        private void buttonKonduct_Click(object sender, EventArgs e)
        {
 

           
            FormPassword formPassword = new FormPassword();

            
            formPassword.Show();

            
            this.Hide();
        }
    }
}
