﻿using System.Data.SqlClient;


namespace kursova_1
{
    class DataBase
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=WIN-3427QTEGR4J;Initial Catalog=KursovaDataBase; Integrated Security=True");

        public void openConnection()//метод открытия бд
        {
            if (sqlConnection.State == System.Data.ConnectionState.Closed)
            {
                 sqlConnection.Open();
            }
        }

        public void closeConnection()//метод закрытия бд
        {
            if (sqlConnection.State == System.Data.ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }

        public SqlConnection GetConnection() 
        {
         return sqlConnection;
        }

    }
}
